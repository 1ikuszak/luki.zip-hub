---
type: resource
tags: [przyklad, kurs, transkrypt]
layer: 3
created: 2026-07-10
updated: 2026-07-10
status: reference
---

# Przykładowy transkrypt callu (do testu proposal-page)

Part of [[_MOC]]

Surowy, nieuczesany transkrypt rozmowy z klientem. Dokładnie taki bałagan dostajesz z realnego callu: przerwania, "yyy", powroty do tematu. Odpal na nim skill proposal-page ("zrób ofertę HTML z tego transkryptu"), żeby zobaczyć, jak z tego chaosu wychodzi gotowa animowana oferta.

Kontekst: rozmowa z Anną, która prowadzi agencję e-commerce (18 osób). Ty sprzedajesz wdrożenie asystenta AI na ich wiedzy.

---

ANNA: to znaczy słuchaj, u nas jest tak że... yyy... my mamy naprawdę dużo wiedzy w firmie, przez te siedem lat to się nazbierało, case studies, procesy, no wszystko. Tylko problem jest taki że to jest wszystko porozrzucane. Część na dysku, część w mailach, część siedzi w głowach ludzi którzy są u nas od lat.

ANNA: i teraz jak przychodzi nowa osoba, junior, to ona przez pierwsze trzy miesiące non stop pyta. I to jest ok, tylko że pyta seniorów, a senior zamiast robić swoją robotę odpowiada na to samo pytanie dziesiąty raz.

TY: a wiecie mniej więcej ile czasu na to schodzi?

ANNA: no słuchaj, ciężko powiedzieć dokładnie, ale... jakbym miała strzelać to każdy senior traci ze dwie, trzy godziny tygodniowo na takie pytania. Mamy pięciu seniorów. To się robi kupa czasu.

ANNA: no i druga rzecz, klienci. Klient pyta "a robiliście coś w mojej branży", i my wiemy że robiliśmy, tylko nikt nie pamięta gdzie to jest, w którym folderze, kto prowadził. Czasem tracimy przez to szansę bo nie umiemy szybko pokazać że mamy doświadczenie.

TY: czyli wiedza jest, tylko nie ma do niej szybkiego dostępu.

ANNA: dokładnie tak. Ona istnieje. My po prostu nie umiemy jej wyciągnąć w odpowiednim momencie. Próbowaliśmy Notion, ale... yyy... szczerze to nikt tam nie zagląda. Zrobił się kolejny cmentarz.

ANNA: i teraz jakby, marzenie byłoby takie, że ktoś nowy przychodzi, pisze pytanie normalnie, po ludzku, i dostaje odpowiedź z naszej wiedzy, z tego jak MY to robimy, nie z internetu. Żeby to było takie... nasze.

TY: a jakby to działało, to co by to dla was zmieniło w liczbach?

ANNA: no gdyby seniorzy odzyskali te dwie, trzy godziny tygodniowo, to jest realnie kilkanaście godzin w firmie tygodniowo. I onboarding nowych ludzi zszedłby z trzech miesięcy do... nie wiem, miesiąca? Plus te sytuacje z klientami, że od razu pokazujemy że mamy case w ich branży.

ANNA: budżet mamy, to nie jest problem, tylko musimy wiedzieć że to nie będzie kolejne Notion do którego nikt nie zagląda. To mnie martwi najbardziej.

## See Also
- [[_MOC]]
- [[_GUIDE]]
- [[_MOC-knowledge]]
