---
name: proposal-page
description: "Zamienia transkrypt callu albo brief klienta w lekką, animowaną, jednoplikową ofertę HTML (nie PDF, nie blok tekstu). Zalockowany design, copy przez frameworki + własny panel sędziów. Triggers: zrób ofertę HTML, oferta jako strona, animowana oferta, proposal page, oferta dla klienta na stronę."
---

# Proposal Page

Zamienia transkrypt z callu albo brief w lekką, animowaną, jednoplikową stronę HTML z ofertą. To artefakt "jak to będzie wyglądać", który sprzedaje twój taste i buduje zaufanie lepiej niż statyczny PDF. Design jest zalockowany, ty dostarczasz treść. Ten sam jakościowy output za każdym razem.

**Kiedy użyć:** oferta B2B, projekt, wdrożenie - wszędzie, gdzie chcesz pokazać "jak to wygląda" i zbudować zaufanie.

## Design system (LOCKED - nie zmieniaj struktury ani CSS)

Wzorzec: `templates/proposal_page_reference.html`.
- **Font:** Helvetica Neue / systemowy. Jeden krój.
- **Kolory:** ciepły papier `#F5F4EF`, głęboki szmaragd `#0F6B52` jako akcent, tekst `#16181C`, muted `#6B6E6B`, linie `#E5E3DB`. Jeden akcent na całą stronę. Zmieniasz TYLKO `--accent` w `:root`, jeśli chcesz kolor swojej marki - nic więcej.
- **Motion:** reveal na scroll (IntersectionObserver, opacity + translateY, staggered) + płynące kropki w diagramie + pulse. ZAWSZE `@media (prefers-reduced-motion: reduce)` = wszystko statyczne.
- **ZERO długiego myślnika (em-dash) i średniego (en-dash).** Polskie diakrytyki ZAWSZE. Zwykły dywiz "-" albo przebuduj zdanie.

## Architektura sekcji (sprawdzona kolejność = pełny łuk perswazji)

1. **Kicker** - mały label (produkt, faza).
2. **Hero** - headline z wymiernym efektem (zrozumiały, nie abstrakcyjny) + lead.
3. **Problem (PAS)** - dwuczłonowy hook + 3 linie anafory eskalującej + punch kosztu + reframe.
4. **Zakres** - intro + 4 karty (label + profesjonalny opis).
5. **Jak działa** - zwięzłe intro + 4-węzłowy animowany diagram + podpis.
6. **Dwie drogi** - kontrast: bez systemu (3 bullety) vs z systemem (3 bullety).
7. **Close** - nagłówek + cena (duża akcentowa + małe "netto") + imię + 3 ikony social. Stopka minimalna.

## Copy: napisz, potem osądź (mini-pętla)

Nie oddawaj pierwszego strzału. Zrób trzy ruchy:

1. **Napisz** copy do wszystkich slotów, ciągnąc z `references/copy-frameworks.md` (głosy, ton, zakazane frazy, framework PAS). **Ton OFICJALNY, nie na luzie** - to ofertę czyta szef albo klient, nie kolega. Zakazane: "w mordę", "czarna skrzynka", "zgadywanie/kombinowanie".
2. **Osądź** jak świeży sędzia bez ego: przeczytaj każdą sekcję i zapytaj "czy to przekonuje szefa/CFO? czy jest konkret, nie ogólnik? czy ton jest profesjonalny?". Wskaż najsłabszą sekcję.
3. **Popraw** tę jedną najsłabszą, zanim pokażesz użytkownikowi.

To ta sama zasada bramki-sędziego, którą znasz z kursu: świeże spojrzenie łapie to, co autor obroni. (Pełne frameworki + reguły tonu: `references/copy-frameworks.md`.)

## Workflow A-Z

1. **Kontekst:** przeczytaj transkrypt/brief. Wyłap: klient, produkt, główny problem, teza (jak to rozwiązujesz), proof, skala. Nie masz transkryptu do testu? Weź `samples/przyklad-transkrypt-callu.md` z paczki.
2. **Copy:** napisz + osądź + popraw (mini-pętla wyżej).
3. **Zbuduj HTML:** skopiuj `templates/proposal_page_reference.html` do nowego pliku i podstaw copy do slotów (zachowaj CSS i strukturę 1:1 - to jest locked design). Uzupełnij cenę, imię, linki.
4. **Sprawdź:** otwórz plik w przeglądarce. Zero długiego myślnika. Diakrytyki OK. Diagram animuje się na scroll.
5. **Iteruj z użytkownikiem:** on edytuje copy linijka po linijce. Gdy prosi o wariant headline'u - daj kilka opcji z krótkim uzasadnieniem, nie jeden strzał.
6. **Wyślij:** plik jako załącznik albo hostuj pod URL i wyślij link. Zapisz projekt w vaulcie.

## Critical rules
- HTML = format oferty. Design LOCKED (Helvetica + szmaragd na papierze). ZERO em-dash. Diakrytyki zawsze.
- Ton oficjalny, nie blunt. Frazy reelowe != frazy ofertowe.
- Cena: nie zaniżaj cicho. Kotwica ("wdrożenie tej klasy to zwykle X") + odwrócenie ryzyka robią robotę, nie rabat.

## Pliki
- `templates/proposal_page_reference.html` - zalockowany design (worked example).
- `references/copy-frameworks.md` - głosy, ton, zakazane frazy, quality gate.
