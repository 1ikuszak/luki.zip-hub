# Copy Frameworks - proposal-page

Frameworki + reguly tonu, ktore obowiazuja przy KAZDEJ edycji copy strony oferty. Spojne z `.claude/rules/writing-craft.md`.

## Glosy (skrzyzuj wszystkie)
- **Hormozi** - nikt nie kupuje technologii, kupuja szybciej/taniej/przewage. Value = (dream outcome x wiarygodnosc) / (czas x wysilek). Risk reversal. "To nie X. To Y." reframe.
- **Dan Koe** - sprzedajesz transformacje, nie funkcje. Lean, czlowiek do czlowieka. Problem -> mechanizm -> wynik.
- **Naval** - specific knowledge (rzecz nie do skopiowania = ustrukturyzowana baza wiedzy). Leverage (system zostaje i rosnie). Na wlasnosc.
- **Scott Adams** - pierwsze zdanie robi robote. Jedno zdanie = jedna mysl. Active voice. Wytnij filler. Pisz jak mowisz.
- **Saraev** - period emphasis, anafora ("Ktos X. Ktos Y. Ktos Z."), specificity > abstrakcja.

## TON: OFICJALNY, nie "w morde" (najwazniejsza lekcja, 2026-06-24)
To oferta B2B czytana przez szefa/CFO. Ma byc profesjonalna i jasna, ale NIE korpo-belkot.

**BANNED (blunt / reel-frazy - wytnij zawsze):**
- "Wolno." (jako sad puenta) -> "co wydluza czas odpowiedzi"
- "czarna skrzynka" -> "brak wgladu" / opisz konkretnie (za trudne/straszy szefa)
- "zmyslania" / "kombinowania" / "zgadywania" jako oskarzenia -> "jasno komunikuje, zamiast zgadywac" / "nie generuje odpowiedzi spoza bazy"
- "jak do kolegi" -> "w naturalnym jezyku"
- "dostawca" gdy niejasne -> "osoba trzecia" / "zewnetrzna firma"
- wykrzykniki, emoji, "bez kitu", slang.

**Reguly zrozumialosci:**
- Headline ma byc ZROZUMIALY, nie abstrakcyjny. (Odrzucone: "Wasza wiedza, ktora sama odpowiada" = za abstrakcyjne. Przyjete: "Wiedza, z ktorej korzysta caly zespol".)
- Kazde zdanie sprawdz: czy szef to zrozumie od razu? Jak nie - przepisz prosciej.
- Krotki punch > dlugie wyjasnienie ("Przy 50-60 osobach to caly etat miesiecznie." zamiast dodawac "stracony na...").

## TWARDE (mechaniczne)
- Polskie diakrytyki ZAWSZE (client-facing).
- ZERO em-dash i en-dash (dlugi/sredni myslnik). Tylko " - " albo przecinek/kropka. Sprawdz w tekscie: liczba obu znakow = 0.
- Konkretne liczby i rzeczowniki (50-60 osob, 2-3 pliki, SharePoint, Teams), nie abstrakcje.

## Nawyk: kilka opcji na kluczowej linii
Gdy iterujesz kluczowa linie (hero, headline sekcji, close), DEFAULTOWO podaj kilka wariantow: kazdy = **pogrubiony wariant** + (tag frameworka) + 1-linijka "why". Na koncu 1-2 rekomendacje. Preferuj bardziej zrozumiale/proste nad sprytne/abstrakcyjne.

## Quality gate (9 kryteriow - przepusc przez nie gotowe copy)
1. ROI/outcome-first lead. 2. Value equation. 3. Risk reversal / wlasnosc. 4. Specific knowledge / moat. 5. Lean/anti-fluff. 6. Villain contrast (kulturalny). 7. Specificity (swap test). 8. **PROFESSIONAL TONE** (bez blunt-fraz, bez korpo). 9. Craft hygiene (diakrytyki, zero em-dash).
