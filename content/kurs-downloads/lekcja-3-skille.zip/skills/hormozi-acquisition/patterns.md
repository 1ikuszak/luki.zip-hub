# Patterns — Hormozi Acquisition Trilogy

Concrete, reusable techniques. Format: When to use / How / Trade-offs.

## Build a Grand Slam Offer (11-point sequence)
**When**: Prospects compare you on price; you need customers AND margin.
**How**: (1) De-commoditize, (2) pick a normal/growing market, (3) charge a lot, (4) design across the 4 value drivers, (5) create value in 5 steps (Dream Outcome → Problems → Solutions → Delivery Vehicles → Trim & Stack), (6) stack + make it profitable, (7) scarcity, (8) urgency, (9) bonuses, (10) creative guarantee, (11) name with MAGIC.
**Trade-offs**: Takes real design time; a half-built offer (skipping enhancers) leaves conversion on the table.

## Value Equation diagnosis
**When**: Any weak offer; any pricing decision.
**How**: Value = (Dream Outcome × Perceived Likelihood) ÷ (Time Delay × Effort & Sacrifice). Grow the top two, drive the bottom two toward zero. Attack the denominator (speed + ease) — that's where amateurs don't compete.
**Trade-offs**: Inflating claims (top) is easy and lazy; the real, defensible wins are in reducing time/effort, which costs more to engineer.

## Starving-Crowd market selection
**When**: Before building any offer.
**How**: Score the market on Massive Pain, Purchasing Power, Easy to Target, Growing. Order of leverage: Market > Offer > Persuasion. Never enter a shrinking market.
**Trade-offs**: A great offer to a bad market fails; committing to one niche (100x price) costs the optionality of chasing many.

## The 5 enhancers (Scarcity / Urgency / Bonuses / Guarantees / Naming)
**When**: Core offer exists; you want to shift the demand curve without changing delivery.
**How**: Limit quantity (scarcity), limit time (urgency), stack named bonuses instead of discounting, reverse risk with a conditional guarantee ("if not X in Y, then Z"), refresh the name/wrapper (MAGIC) to re-run the same offer forever.
**Trade-offs**: Fake scarcity/urgency destroys credibility; a guarantee multiplies refunds on a bad product — enhancers amplify a good offer, they can't save a bad one.

## Client Financed Acquisition (the Money Model bar)
**When**: Any paid-acquisition engine.
**How**: Chain Attraction → Upsell → Downsell → Continuity so 30-day gross profit from one customer covers getting AND servicing at least two. Front-load cash; measure payback in days.
**Trade-offs**: Requires multiple offers built in sequence; a one-offer "front end" leaves most profit (offers 2-4) unclaimed.

## Attraction Offers (5 tools)
**When**: Stage I — turn strangers into customers, cover CAC.
**How**: Win Your Money Back (pay now, earn it back on results), Giveaway (Grand Prize → everyone-else discount), Decoy (cheap bait → push premium), Buy X Get Y Free (discount reframed as free), Pay Less Now/Pay More Later (card on file + conditional guarantee).
**Trade-offs**: Only run Win Your Money Back under 5% refund rate; free pulls more leads but lower show-rate than discount.

## Upsell Offers (4 tools) — the profit center
**When**: Immediately after the core purchase reveals the next problem.
**How**: Classic ("can't have X without Y"), Menu (Unsell→Prescribe→A/B→Card on File), Anchor (5-10x price first, then rescue), Rollover (credit past spend toward a bigger offer, priced ≥4x the credit).
**Trade-offs**: Wrong time / too different / not believed = the three ways upsells fail. Anchor must be genuinely sellable, not fake.

## Downsell Offers (3 tools)
**When**: After a "no" — no means no to THIS offer, not all offers.
**How**: Payment Plan (same price, spread — 7-step ladder), Trial With Penalty (pay only if you DON'T meet terms), Feature Downsell (cut a high-value feature so they re-sell themselves the full offer). Alternate payment + feature with 1-10 temperature checks.
**Trade-offs**: Payment plans cannibalize would-be full-payers if paid-in-full count drops; never discount the identical thing (trains customers to wait for sales).

## Continuity Offers (3 tools) — run LAST
**When**: Stage III — after cash offers, to add recurring revenue.
**How**: Continuity Bonus (sell the bonus, membership is free), Continuity Discount (free time by 4 timings matched to churn), Waived Fee (setup fee waived for a term; leaving costs the fee). Add 4-week billing + 3% processing fee.
**Trade-offs**: Continuity alone crashes 30-day cash — never lead acquisition with it. Frontloaded discounts convert more but churn more.

## Promotional Wrappers (Premium / Free / Discount)
**When**: Entering a cold market; presenting one Grand Slam Offer.
**How**: Premium = full price standalone (needs proven process + cash). Free = max response, cheapest leads, monetize downstream + friction ladder. Discount = 50%+ on a splintered piece → two-step sale (capture card, kill no-shows, upsell premium). Sequence: Get Flow → Monetize → Add Friction.
**Trade-offs**: Premium has no margin for weak copy; free needs a "Why?" answer or it's disbelieved; marginal discounts (5-25%) just bleed margin.

## Make Your Money Model (3-stage build)
**When**: Building or fixing the whole engine.
**How**: Stage I Get Cash (Attraction) → Stage II Get More Cash (Upsell/Downsell) → Stage III Get The Most Cash (Continuity). Perfect one offer at a time (reliable → automatic → advance). Start cheap for yeses/feedback, then raise price until profit stops rising. Measure in quarters.
**Trade-offs**: Installing a full model day one breaks a young business; each stage must pay for the next before advancing.
