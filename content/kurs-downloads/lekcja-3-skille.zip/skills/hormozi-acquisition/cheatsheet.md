# Cheatsheet — Hormozi Acquisition

Decisions, thresholds, and tells. Not definitions (see glossary) — judgment.

## Decision rules

- **Pricing**: Raise value first, then charge "as high as you can say out loud without cracking a smile." No benefit to being 2nd-cheapest; real benefit to being most expensive.
- **Lower price only if** you've cut delivery cost to ~1/10 of competitors. Otherwise raise it — 99% of businesses need to charge more, not less.
- **Market beats offer beats persuasion.** Never enter a shrinking market, however good your offer/skill. Get rich in a normal market; go broke in a dying one.
- **Which promotional wrapper**: proven sales process + cash → Premium. New / low-volume / cash-strapped → Free or Discount first, prove results, then restructure to Premium.
- **Free vs Discount**: need max volume + cheapest leads in a small pond → Free. Free legally restricted OR service well-understood (dentist, gym) → Discount 50%+.
- **When a no-show is costly** (doctors, lawyers, high-value slots) → use Discount/paid front-end, not Free (paid = 85-90% show).
- **Close without discounting**: add a named bonus that matches their objection, ask again ("fair enough?"). Discounting the core trains customers to wait for sales.
- **After a "no"**: change HOW they pay (payment plan / trial) to keep price whole; change WHAT they get (feature downsell) to lower it. Never discount the identical thing.
- **Continuity runs LAST**, never as the standalone attraction offer — it crashes 30-day cash.
- **Build order**: Get Cash → Get More Cash → Get The Most Cash. Perfect one offer (reliable → automatic) before advancing a stage.
- **New offer, cheap first**: launch low to harvest yeses + feedback, improve product, then raise price until extra yeses no longer beat added nos.
- **Fixing a fatiguing offer, change in this order**: creative → body copy → headline/wrapper → duration → free/discount enhancer → monetization structure (last resort).

## Thresholds & numbers

- **Refund rate < 5%** required before running Win Your Money Back (or fix the product first).
- **Rollover Upsell**: price the next offer ≥ 4x the credit (so full credit = max 25% discount, still profitable).
- **Guarantee math**: close 130% as many at 2x refund rate (5%→10%) and still net 1.23x. A guarantee loses only if the sales lift is 100% offset by refunds.
- **Waived-fee / setup fee** = 3-5x the monthly rate.
- **Billing cadence → churn** (14k businesses): monthly 10.7% / quarterly 5% / annual 2%. Start high.
- **4-week billing** = 13 cycles/yr = +8.3% revenue for free (+41% profit at 20% margin).
- **3% processing fee** on topline ≈ +30% profit for a 10%-margin business; waive it for a backup card.
- **Penny gap**: $0.01 → free = ~9x more takers.
- **Discounts**: only 50%+ moves behavior; 5-25% just bleeds margin.
- **Standalone-vs-continuity dial**: one-time price 1.33x monthly → ~50% pick continuity; 2.66x → ~90%.
- **Fractal demand**: ~1/5 of prospects will pay ~5x. Skim the top.
- **Premium math**: same 190 leads, close 5% at $9,500 profit = 9.5x more than 190 sales at $50.

## Tells & smells

- **"You have a front end, not a business"** — you sell only one thing. Add offers 2-4 (that's where the profit is).
- **Fully booked but broke** = margins too thin; you competed on price. Raise it.
- **Free offer flopped** → prospects (1) don't want it, (2) don't believe you, or (3) don't see it (wrong pond).
- **Unbelievably good free offer gets zero response** → you didn't answer "Why?" (credibility gap).
- **Paid-in-full count drops after adding a payment plan** → the plan is cannibalizing your best cash.
- **80%-qualified campaign "feels" better** but produces fewer total qualified leads → judge by Free Money Math (dollars), not percentage.
- **"Business terrorist"** demands the same thing for less → never a naked discount; offer payment plan or feature downsell.
- **>5% want to cancel early** → fix the product; a fee should nudge, not imprison.
- **Money Model starts working → business starts breaking** → build/hire the team; expect the operational strain.
