# Chapter 8: Upsell Offers

## Core Idea
An Upsell is simply "whatever you offer next" — the moment your first offer solves one problem, another appears, and the upsell solves that one for more cash. Upsells usually make the MAJORITY of the profit, so the thing you sell most isn't the thing you profit most on.

## Frameworks Introduced
- **The Classic Upsell**: Solve the customer's next problem the instant they become aware of it. Structure: "You can't have X without Y."
  - When to use: whenever your core purchase creates an immediate, obvious follow-on need (car → insurance → gas; bike → helmet → lights; exercise course → nutrition course).
  - How: know the problem better than the customer does (it's your business). Offer higher-profit upsells first. Give access as fast as possible — the sooner they hold it, the more they value it and the harder it is to hand back. Use "You don't want anything else, do you?" to get people to say NO (which means yes). Bundle-and-name upsells ("Transformation Package") to make one ask land many sales.
  - Why it works: current customers always convert higher than strangers, and timed right, customers upsell themselves. You lose nothing by offering to solve a problem — the worst outcome is they'd have said yes and you never asked.
- **Menu Upsell**: Tell customers what they DON'T need, then prescribe what they do, ask their preference, and close on the card on file. Combines four tactics: Unselling → Prescription → A/B → Card On File.
  - When to use: when you have multiple offers/SKUs available and want to maximize per-customer spend without pressure.
  - How: (1) **Unsell** — cross out what they don't need to build goodwill and spotlight what they do; (2) **Prescribe** — tell them exactly how to use what they need (as if they already own it), integrated with what they bought; (3) **A/B** — ask "chocolate or vanilla?" not "do you want it?" (either answer = a sale); add a nudge ("this is my favorite") for inexperienced buyers; (4) **Card On File** — "Wanna just use the card on file?" removes hidden buying costs.
  - Why it works: removing the option to NOT buy (prescribe/A-B) plus removing friction (card on file) plus goodwill (unsell) compounds. Employees love helping customers "game the system" — let them; everyone wins.
- **Anchor Upsell**: Present a premium offer at 5-10x price first; when the customer gasps, rescue them with the acceptable main offer, which now looks like a great deal.
  - When to use: to raise average order value and skim the few who'll actually buy the premium.
  - How: (1) present the anchor for real (not as a fake); (2) get "The Gasp"; (3) come to the rescue — "Do you care about [the premium feature]?"; (4) present the main offer, same PRIMARY features, cheaper secondary ones; (5) ask which card. Bigger gasp = bigger purchase. Make a premium you'd genuinely be happy to deliver — some will buy it.
- **Rollover Upsell**: Credit some/all of a customer's previous purchase toward your next, more expensive offer.
  - When to use: four situations — re-engage lapsed customers, rescue your own upset customers (before refunding), "rescue" competitors' upset customers, upsell current customers.
  - How: decide who / what (more, better, or new) / how (credit up front or spread over time). Price the next offer at least 4x the credit so full credit = max 25% discount and you still profit. Add one-time-only urgency. Don't credit the entire first purchase unless needed — test the sweet spot.

## Key Concepts
- **"Say no to say yes"**: Phrasing ("you don't want anything else, do you?") that converts the trained "no" reflex into a purchase.
- **Hyper Buying Cycle**: A short window when someone commits to something new (wedding, baby, new hobby, moving) and spends heavily — stack offers here.
- **Unselling**: Telling customers what they don't need to earn the right to sell what they do.
- **Prescription Upsell**: Telling them how to use a product as if they already bought it, removing the buy/don't-buy decision.
- **A/B Upsell**: Offering a choice between two things instead of a yes/no on one thing.
- **BAMFAM (Book-A-Meeting-From-A-Meeting)**: Never end an appointment without scheduling the next — more upsell chances = more upsells.
- **The Gasp**: The customer's mini panic at the anchor price; bigger gasp correlates with bigger eventual spend.
- **Bundle-and-name**: Packaging multiple upsells under one result-based name to sell nine things in one ask (and peel features off later as downsells).

## Mental Models
- Think of every solved problem as a door to the next offer — upsells even have upsells.
- Upsells come in three flavors: more (quantity), better (quality), or different (complementary). Match the flavor to the revealed problem.
- Give free bonuses that CREATE the problem your next upsell solves (free earmuffs → $30 to store them).
- "The faster people get access, the more they value it" — put the upsell in their hands before they say yes; giving something back is harder than saying no.
- Charge for guarantees/warranties/insurance instead of giving them free (+5-50% price) — pure profit (the art studio went from free repairs to 30% paying an extra 10%).

## Anti-patterns
- **Only selling one thing**: "You have a front end, not a business." Figure out your "Do you want fries with that?" or a competitor will.
- **Upselling at the wrong time/way**: offering something too different, before they've felt the problem, or in a way they don't believe — the three ways upsells fail.
- **Treating the anchor as fake**: gloss over the premium and it never gets considered; you must genuinely sell it for the anchor to work.
- **Being shy about number of offers**: offer as many solutions as there are problems — the worst outcome is a yes you never asked for.

## Worked Example
The burger-shop math (why upsells make or break a model): a $2.00 burger nets $0.25 profit — you'd need ~10,000/day to scrape a living. Add "Fries with that?" (+$0.75 → $1.00, 4x). "Make it a meal?" adds a drink (+$0.75 → $1.75, an 8x total from the burger alone). "Supersize for a buck?" pushes profit to ~$3.00 — an 11.6x increase over the burger's original $0.25. The first offer (the burger) is what sells most; offers 2-4 are where the business actually lives. No McDonald's without fries and soda. Contrast the Menu Upsell origin: Hormozi, failing to sell supplements to 19 straight consults, abandoned the science pitch and just asked appointment #20 "chocolate or vanilla?" — she picked, bought, and he closed the next 20 in a row by A/B-asking preferences and closing on the card on file.

## Key Takeaways
1. Your first offer usually isn't your profit center — the profit lives in offers two, three, and four.
2. Ask for the preference (A/B), not the yes/no — removing "no" as an option raises take-rate.
3. Speed of access raises perceived value; close on the card on file to kill friction.
4. Anchor high to sell the middle, and pocket the few who buy the top.
5. Rollover previous spend (yours or a competitor's) to make the next, bigger offer feel free — priced 4x the credit to stay profitable.
6. BAMFAM: every meeting ends by booking the next meeting and reason.

## Connects To
- **Ch 6**: Upsells are the profit engine of the Money Model — they're what push 30-day profit above CAC (the CFA math).
- **Ch 7 (Attraction)**: The Attraction Offer reveals the problem; the upsell solves it. Win Your Money Back's applied winnings = a Rollover Upsell.
- **Ch 9 (Downsells)**: Bundle-and-name upsells get "peeled" into Feature Downsells when someone says no.
- **Ch 10 (Continuity)**: Anchor and bundle logic reappears in Continuity Bonus stacking; Rollover Upsell rolls credit into a continuity term.
- **Offers Ch 4 (Bonuses)**: Free bonuses that manufacture the next problem are the setup for Classic Upsells.
