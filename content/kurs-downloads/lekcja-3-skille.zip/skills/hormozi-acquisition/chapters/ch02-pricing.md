# Chapter 2: Pricing — How To Charge Lots of Money For Stuff

## Core Idea
Escape commoditization by building a Grand Slam Offer that sells in a "category of one," then pick a starving-crowd market and charge premium prices — because raising price (after raising value) is the fastest, most moral path to a business that can actually serve people well.

## Frameworks Introduced
- **Grand Slam Offer (full definition)**: An offer that cannot be compared to any other product, combining an attractive promotion, an unmatchable value proposition, a premium price, and an unbeatable guarantee, with a money model (payment terms) that lets you get paid to acquire customers.
  - When to use: whenever prospects are comparing you on price.
  - How: differentiate so hard the buying decision becomes "your product vs. nothing," then price to perceived value, not to competitors.
  - Why it works: it lifts all three growth levers at once — response rate (clicks), conversion (sales), and premium price. Same fulfillment work, radically different perceived product.
- **The Starving Crowd (market selection)**: Market demand outranks offer and skill. Order of importance: **Starving Crowd (market) > Offer Strength > Persuasion Skills.**
  - When to use: before building any offer — a great offer to the wrong market falls on deaf ears.
  - How: score market as great/normal/bad. A "great" on a higher lever overpowers weakness below it; a "bad" market stops the equation unless a higher "great" nullifies it. You can get rich in a *normal* market; you cannot in a *bad* (shrinking) one.
  - Four indicators: (1) Massive Pain, (2) Purchasing Power, (3) Easy to Target, (4) Growing.
- **Virtuous Cycle of Price**: Raising price increases emotional investment → perceived value → client results → attracts best/easiest clients → multiplies margin to reinvest. Lowering price reverses every arrow.
- **Three Ways to Grow**: (1) more customers, (2) increase average purchase value, (3) get them to buy more times. (Author simplifies to two: get more customers, increase each customer's value.)

## Key Concepts
- **Commodity**: A product available from many places, priced by market efficiency; if all products look "equal," the cheapest wins by default.
- **Gross Profit**: Revenue minus the direct cost of servicing an *additional* customer (not net profit).
- **Lifetime Value (LTGP)**: Gross profit accrued over a customer's lifetime = gross profit × number of purchases. Hormozi counts gross profit, not revenue.
- **Price-to-Value Discrepancy**: People buy to get a deal — value received must exceed price paid. The moment value dips below price, they stop buying.
- **Niche pricing**: The more specific the avatar, the more you can charge for a near-identical product (up to ~100x).
- **Niche slap**: The penalty for hopping markets instead of committing; you restart from zero each time.

## Mental Models
- Think of price as a *value signal*: in the blind wine study the same wine was rated best/worst purely by displayed price. Raising price can literally raise perceived value with zero product change.
- Use "charge as high as you can say out loud without cracking a smile" (Dan Kennedy). There is no strategic benefit to being second-cheapest; there is for being most expensive.
- Price so it *stings* — those who pay the most pay the most attention, get more invested, and get better results. Premium pricing is therefore pro-customer.
- Don't create demand — *channel* it. Serve people who can pay you what you're worth; don't sell ice to Eskimos.

## Anti-patterns
- **Market-average pricing** (look at market → go slightly below → offer "more for less"): you're copying competitors who are dead broke, pricing yourself to bare survival.
- **Lowering price to increase the value gap**: the wrong move for most — you can only go down to $0 but infinitely high the other way. Only viable if you've cut costs to ~1/10 of competitors.
- **Fighting a shrinking market** (Lloyd's newspaper software): great product, zero-risk revshare offer, natural salesman — still declined 25%/yr because the market was dying.
- **Niche-hopping** ("I'll switch from dentists to chiropractors"): both are billion-dollar normal markets; the problem was no Grand Slam Offer yet, not the niche.

## Worked Example
**Commoditized vs. Grand Slam Offer (lead-gen agency).** Old way: $1,000 down + $1,000/mo retainer. At 0.5-1x ROAS you *lose* money acquiring customers and only break even after month one. New Grand Slam Offer: "Pay once, no retainer, just cover ad spend. I generate and work your leads, only pay if people show up, guaranteed 20 people month one or next month free — plus the entire industry playbook, scripts, pricing, coaching, free." Result: 2.5x more responses × 2.5x conversion × 4x higher price = **22.4x more cash collected up front** — spend $10,000, make $112,000. Same fulfillment work; the offer did the differentiating. **Niche pricing ladder (Dan Kennedy):** a generic "Time Management" course = $19; "for Sales Professionals" = $99; "for B2B Outbound Sales Reps" = $499; "for B2B Outbound Power Tools & Gardening Sales Reps" = $1,000-2,000. Same core content, ~100x price.

## Key Takeaways
1. Pick the market first — Starving Crowd beats Offer beats Persuasion. Never enter a bad (shrinking) market.
2. Score any market on pain, purchasing power, targetability, growth. Health/Wealth/Relationships always exist; niche into a growing, moneyed, easy-to-reach subgroup.
3. Commit to one niche until it works. Riches are in the niches; niching down 100x's price on the same product.
4. Charge a premium and raise price only *after* raising value — the buyer still gets $100k of value for $10k ("money at a discount").
5. Profit is oxygen. 99% of businesses need to raise prices to grow, not lower them; margin funds the value that keeps the virtuous cycle spinning.

## Connects To
- **Ch 3**: Value Equation — the mechanism that justifies the premium price this chapter demands.
- **Ch 4**: Guarantees, scarcity, urgency, naming — the "unbeatable guarantee" and "attractive promotion" halves of the Grand Slam Offer definition.
- **Money Models (ch06-ch11)**: The "get paid to get customers" payment terms that make the 22.4x math survivable on cash flow.
