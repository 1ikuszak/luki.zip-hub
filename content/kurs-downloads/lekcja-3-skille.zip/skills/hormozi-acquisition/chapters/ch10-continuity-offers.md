# Chapter 10: Continuity Offers

## Core Idea
Continuity Offers provide ongoing value that customers pay for again and again until they cancel — you sell once and get paid repeatedly. Alone they crash 30-day profit (little cash today); used LAST in the sequence they add a final sale plus stacked recurring revenue. "You can shear a sheep for a lifetime, but you can only skin it once."

## Frameworks Introduced
- **Continuity Bonus Offer**: Give a high-value bonus (worth more than the first payment) for signing up today — get more people to START by adding good stuff (bonuses) and removing bad stuff (discounts).
  - When to use: to convert Attraction/Upsell buyers into recurring members, or as an attraction hook (advertise the giveaway, not the membership).
  - How: sell the bonus's benefits FIRST, use it as an anchor, then reveal "want to know how to get this for free? Become a member." Stack multiple bonuses with individual dollar values. Make bonuses related to the core offer (so you attract right-fit leads) and things you already have/do (past newsletters, onboarding). Then upsell a discounted bulk prepay to front even more cash.
  - Why it works: "get this free valuable thing" beats "join my membership." Then bulk-prepay upsell ("buy 5 months get 1 free") — only 1 in 8 taking it raises 30-day profit ~50%.
- **Continuity Discount Offer**: Give free time (now or later) if the customer commits today — the continuity-style cousin of Buy X Get Y Free.
  - When to use: rentable/recurring services (internet, pool, landscaping, gyms, storage) where you can commit customers to a term.
  - How: apply the discount one of four ways, chosen by your churn profile — (1) **Up front** (free time first, term starts after; only for industries that enforce contracts, delays cash); (2) **At the end** (earn bonus time by paying every installment on time; lowest cancellation, converts fewer); (3) **Spread over time** (e.g., $600 over 12 months = $50/mo off — keeps cash flowing while giving full discount); (4) **After first 1-2 payments** (collect some cash + verify a valid card via "first and last month" / activation fee).
  - Why it works: frontloaded converts more but churns more; backloaded converts fewer but retains. Pair with a lifetime discount unlocked at your most common churn month to pull customers through the drop-off point.
- **Waived Fee Offer**: Offer month-to-month WITH a big setup fee, OR waive the fee entirely if they commit to a term. If they cancel inside the term, they pay the fee.
  - When to use: commitments of a year or longer, especially services that take time to work (SEO, investing, weight loss) — the traditional-contract option.
  - How: set the fee at 3-5x the monthly rate. "You can go month-to-month with a big setup fee and leave whenever, or commit to a year and I'll waive it." Have them initial that early cancellation triggers the fee.
  - Why it works: "Customers stay longer if leaving costs more than staying." The fee gets them to START (avoid it now) AND to STICK (canceling costs the fee); once past the midpoint, canceling costs about the same as finishing, so they finish. Drop the fee once they complete the commitment.

## Key Concepts
- **Continuity Offer**: Ongoing value for ongoing payment until cancellation — boosts every customer's total value and gives you one last thing to sell.
- **The continuity tradeoff**: A $50/mo offer might convert 40/100 (vs. 10/100 at $1,000), turning "$10,000 now, $0 later" into "$2,000 now, $40,000 later" — plus 4x the customers to upsell.
- **4-week (weekly) billing** [highest value-per-word note in the book]: Billing "$100 every 4 weeks" instead of "$100/month" = 13 cycles/year vs. 12 = 8.3% more revenue for zero extra work (at 20% margins, +41% annual profit).
- **Processing fee**: "$X plus a 3% processing fee" — nobody refuses over it; 3% on the topline flows straight to the bottom (a 10%-profit business +3% = +30% profit).
- **Two forms of payment**: Waive the 3% fee in exchange for a backup card — fixes expired/declined cards, the #1 recurring-revenue leak. Get ACH if possible (cheapest to transact).
- **Cancellation policy**: Preferred = cancellation fee equal to the discount they got, returning them to month-to-month rate.
- **Exit interview**: Offer to waive the cancellation fee for feedback — saves ~1/3 of would-be cancellers and surfaces upsell/rollover chances.
- **Titles as bonuses**: Silver/Gold/Diamond status can matter to customers more than any tangible bonus.

## Mental Models
- Continuity is the "get the most cash" layer — never the acquisition layer on its own, because it starves you today.
- Standalone-vs-continuity pricing dial: the smaller the one-time price relative to the monthly, the more choose one-time; the larger, the more choose continuity. (1.33x standalone → ~50% pick continuity; 2.66x → ~90%.) Charging 33% more for a one-time option still gets half to take it — pure up-front cash.
- Free bonuses and discounts are interchangeable — "Become a member for $200, get this $1,000 program free" = "Get the $1,000 program for $1 if you join for $200."
- Make cancellation EASY and visible — hidden exits become public 1-star reviews; a clear path is your chance to save them.

## Anti-patterns
- **Using continuity as a standalone Attraction Offer**: converts more but crashes 30-day cash, making profitable advertising nearly impossible.
- **Inflating bonus anchor values**: unbelievable numbers don't anchor and cost you trust — use real, previously-sold prices.
- **Frontloaded discounts with high historical churn**: you'll give away free time and lose them before profit — backload or spread instead.
- **Handcuffing with fees over a bad product**: if >5% want to cancel early, fix the product — pricing nudges, it shouldn't imprison.
- **Bonuses unrelated to the core offer**: a free t-shirt to sell tech services attracts the wrong customers.

## Worked Example
The Continuity Bonus origin (2019). A once-struggling gym posted numbers above the best performers. His secret: he marketed the six-week challenge but pivoted on arrival. Normal pitch, explain price, then "want to get it for free?" — yes — "become a member and it's free, PLUS members get exclusive bonuses" (better class times, tanning, VIP events). Then the bulk upsell: "wanna save even more money?" → discounted 6-month prepay. The numbers shifted from 34/100 taking the challenge and converting half (17) to stay, to only 15/100 taking the challenge but 40/100 going STRAIGHT into continuity — of whom ~8 took the 6-month prepay. He tripled membership sales, still got up-front challenge cash, AND stacked prepaid cash. This is the canonical stack: Attraction/Upsell/Downsell for today's cash → Continuity Bonus for the first recurring payment → discounted bulk prepay for more front cash → auto-roll into month-to-month.

## Key Takeaways
1. Never lead acquisition with continuity — run it LAST, after the cash offers, so you keep 30-day profit and add recurring revenue.
2. Advertise the bonus/free thing, not "join my membership."
3. Bill every 4 weeks and add a 3% processing fee (waived for a backup card) — massive profit for changing a few words.
4. Match the discount timing (up-front / end / spread / after 1-2 payments) to your churn profile.
5. Waived Fee Offers keep people committed by making leaving cost more than staying.
6. Make cancellation easy and run exit interviews — you save ~1/3 and find rollover upsells.

## Connects To
- **Ch 6**: Continuity is Stage III of the Money Model ("Get The Most Cash") — it maximizes each customer's total spend once acquisition is self-funding.
- **Ch 7 (Attraction)**: Continuity Discount is Buy X Get Y Free done recurring-style; Giveaway/Pay-Later discounts roll into subscriptions.
- **Ch 8 (Upsells)**: Bonus stacking uses Anchor logic; bulk-prepay is a Classic/Rollover Upsell onto the continuity base.
- **Ch 9 (Downsells)**: Feature-downsell elements build better bonuses; cancellation → Rollover Upsell into higher service.
- **Ch 11**: Continuity is the final layer assembled after Attraction → Upsell → Downsell in the full Money Model.
