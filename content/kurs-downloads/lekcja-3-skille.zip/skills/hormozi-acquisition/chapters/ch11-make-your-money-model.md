# Chapter 11: Make Your Money Model

## Core Idea
A Money Model is a deliberate sequence of offers — what you offer, when, and how — engineered to make enough money from one customer to get and service at least two more inside 30 days. It's built one offer at a time across three stages, never all at once, because a "finished" model dropped onto a zero-revenue business collapses on top of you.

## Frameworks Introduced
- **The Three Stages of a Money Model**: Build in order; each stage must pay for the next before you advance.
  - **Stage I — Get Cash**: Attraction Offers get more customers for less (get customers reliably, then make them pay for themselves).
  - **Stage II — Get More Cash**: Upsell & Downsell Offers make more money from them faster (make them pay for OTHER customers reliably).
  - **Stage III — Get The Most Cash**: Continuity Offers maximize each customer's total lifetime spend, then you spend every ad dollar you can to print money.
  - When to use: as the sequencing rule for building or fixing any acquisition engine.
  - How: get customers reliably → make sure they pay for themselves → make sure they pay for the NEXT customers → maximize long-term value → scale ad spend. Measure in quarters, not weeks.
  - Why it works / failure mode: Money Model growth tracks business growth. Skip stages and you break financially and operationally. "When your Money Model starts working, your business starts breaking" — find someone to build the team (Hormozi married her).
- **The 4-Step Build**: Assemble the sequence one offer type at a time.
  - Step 1) Start with an Attraction Offer — turn strangers into customers and cover costs (Win Your Money Back, Giveaway, Decoy, Buy X Get Y Free, Pay Less Now/Pay More Later). Finding what works can take up to a year.
  - Step 2) Pick an Upsell Offer — push 30-day profit well above CAC + delivery (Classic, Menu, Anchor, Rollover); offer it at the moment of greatest need.
  - Step 3) Pick a Downsell Offer — convert the nos (Payment Plan, Trial With Penalty, Feature Downsell); alternate them in one sale.
  - Step 4) Pick a Continuity Offer — grab one last sale in the 30-day window and stack recurring cash (Continuity Bonus, Continuity Discount, Waived Fee); sometimes best timed after day 30, and that's OK.

## Key Concepts
- **$100M Money Model**: Makes more profit from ONE customer than it costs to get and service MANY in 30 days — eliminates cash as the bottleneck to scaling. Mission accomplished.
- **Perfect one offer at a time**: Get one offer reliable → then automatic → then advance a stage. "You either build it right or you build it again."
- **Raise price in stages**: Launch cheap to harvest yeses and feedback, improve the product, then raise price until you stop making more money (until the extra cash from yeses no longer covers the added nos).
- **Simple Scales, Fancy Fails**: 100 ways to offer your product, not 100 products. (One personal-training service → 1/2/3/4 sessions per week = many offers.)
- **Affiliate products fill Money Model gaps**: Sell others' stuff for commission to add offers with no delivery headache — works at every size, from no-product startup to $100M business.
- **Automatic renewal**: Turn an Attraction Offer into a Continuity Offer for free (Buy 6 Get 6 Free auto-rolls into month-to-month at month 12).
- **Mix and match**: No rules — use Upsell tactics inside Attraction Offers, install a Downsell process on every offer, use Continuity to attract. Start Hormozi's way, then experiment.

## Mental Models
- Think of the Money Model as evolving WITH the business, not a blueprint you install day one — even Acquisition.com started at Stage I.
- "Each stage pays for the next" — don't move to upsells until attraction reliably gets customers; don't add continuity until upsell/downsell reliably fund the next customer.
- Patience is the fastest route: building again (however fast) always takes longer than building it right once.
- A single offer can wear multiple hats — the newsletter "six-headed monster" is simultaneously Attraction, Upsell, and Continuity.

## Anti-patterns
- **Implementing a whole Money Model at once**: it breaks a young business — stick to your stage, perfect one offer.
- **Starting new businesses just to add offers**: creates a hundred businesses' worth of problems; add offers or affiliate products instead.
- **Measuring in weeks**: Money Models mature in quarters; impatience makes you rebuild.
- **Pricing too high too early**: you need early yeses for feedback before you ratchet price up.

## Worked Example
Gym Launch's actual evolution to a $100M Money Model, stage by stage:
- **Stage I (Attraction — Decoy Offer)**: Free courses/books/trainings on growing a gym, each with a free call. On the call: free DIY plan (decoy) vs. $16,000 / 16-week Done-With-You licensing (premium). → $476,000/month in three months.
- **Stage II (Upsell — Classic Upsell + Continuity Bonus, Downsell — Payment Plan)**: "Gym Lords" at $42,000/year ($36,000 prepaid) with advanced playbooks + a community as a Continuity Bonus, sold with a $6,000 prepay discount (often paid with money he'd just made them). For nos: seesaw Payment Plan — $10,000 down + rest over 52 weeks → ~$800/week for 52 weeks → start free via a Continuity Discount that frontloaded free time until they finished paying the first offer, then rolled into continuity. → ~$1,500,000/month.
- **Stage II deepened (Menu Upsell + Feature Downsell)**: Personalized menu — Done-For-You advertising, sales training, turnkey campaigns, and a $100/week "Minimum" package (original materials + tech support). Feature Downsells found everyone a fit; almost all stayed for something. → $2,300,000/month, all within 14 months.
- **Then Prestige Labs** (a separate business with its own Money Model, integrated) → $4,400,000/month by month 20.
Author's note: "When I started, I didn't know any of this. It only looks clean looking back."

## Key Takeaways
1. Build in stages (Get Cash → Get More Cash → Get The Most Cash); make each stage reliable and pay for the next before advancing.
2. Perfect one offer at a time — reliable, then automatic, then next. Measure in quarters.
3. Start offers cheap for yeses + feedback, then raise price until profit stops rising.
4. 100 ways to sell one product beats 100 products; use affiliate offers to fill gaps without delivery.
5. Mix and match freely — one offer can be Attraction, Upsell, and Continuity at once.
6. The endgame: one customer funds many. Cash stops limiting growth — that's the whole point.

## Connects To
- **Ch 6**: Delivers on the thesis — the staged build is HOW you reach Client Financed Acquisition and the 30-day self-funding math.
- **Ch 7-10**: This chapter assembles all four offer-type toolkits (Attraction → Upsell → Downsell → Continuity) into one sequence.
- **Offers (ch01-05)**: Answers "how do I get them to buy?" — the third book after $100M Offers ("what to sell" / Grand Slam Offer, Value Equation) and $100M Leads ("how to find them").
- **Leads (ch12-13)**: Step 1's advertising depends on the Leads book; a working Money Model is what lets you outspend everyone because customers fund the ad budget.
- **Ten Years in Ten Minutes**: The book's own one-page recap of all four offer types and the staged build — the compression of this chapter.
