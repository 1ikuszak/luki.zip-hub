# Chapter 3: Value — Create Your Offer

## Core Idea
Value is a quantifiable equation, not a vibe. Maximize perceived value by growing dream outcome and likelihood of achievement while driving time delay and effort/sacrifice toward zero — then build the offer by listing every problem a prospect faces and stacking a solution for each.

## Frameworks Introduced
- **The Value Equation**: Value = (Dream Outcome × Perceived Likelihood of Achievement) ÷ (Time Delay × Effort & Sacrifice).
  - When to use: to diagnose why any offer is weak and to price/design any product.
  - How: increase the two numerator drivers, decrease the two denominator drivers. It's division, not addition, deliberately — drive the bottom toward zero and value approaches infinity (anything ÷ 0 → undefined/infinite).
  - Why it works: beginners inflate the top (bigger claims = easy, lazy, non-unique). The market rewards the *bottom* — making things immediate and effortless (Apple, Amazon 1-click, Netflix). Focus your competitive energy there.
- **The Offer-Creation Thought Process (5 steps, Ch9-Ch10)**: (1) Identify Dream Outcome, (2) List Problems, (3) Convert Problems to Solutions, (4) Create Solution Delivery Vehicles ("the how"), (5) Trim & Stack.
  - How: for each core action the customer must take, list every reason (mapped to the 4 value drivers) they won't do it or keep doing it; reverse each into a "How to..." solution; brainstorm delivery vehicles; then trim to high-value/low-cost items and bundle.
- **Divergent vs. Convergent Thinking**: Convergent = many known variables → one right answer (math). Divergent = multiple/unknown variables, dynamic conditions, many right answers (one far better than others). Offer-building requires divergent thinking.
  - How: the "Brick Exercise" — 120 seconds listing as many uses for a brick as possible; questioning size/material/shape unlocks far more uses. Every offer has building blocks; combine them many ways.

## Key Concepts
- **Dream Outcome**: The gap between the prospect's current reality and their envisioned feelings/experiences. Goal: accurately reflect it back so they feel understood. Sell the vacation, not the plane flight.
- **Perceived Likelihood of Achievement**: The buyer's belief they'll actually get the result. People pay for certainty (the 10,000th patient vs. the 1st surgeon).
- **Time Delay**: Time between purchase and receiving the promised benefit. Split into long-term outcome (what they buy) and short-term experience (what makes them stay).
- **Effort & Sacrifice**: The tangible/intangible ancillary costs "along the way." Why done-for-you > do-it-yourself, and liposuction > bootcamp.
- **Status**: The perceived increase/decrease in relative social standing — the deeper driver under most dream outcomes (Collette's minivan over the Lambo).
- **Perception is reality**: The value drivers only count when the prospect *perceives* them (the London tube dotted map beat faster trains).

## Mental Models
- Use *psychological* solutions over logical ones (Rory Sutherland): logical fixes are already tried; add a dotted map instead of faster trains, mirrors instead of faster elevators.
- Frame benefits as status *from others' viewpoint* — "your golf buddies' jaws will drop." Connect the dots to how others will perceive them.
- Engineer a big, fast emotional win early ("Fast Wins") to secure the long-term commitment — get a gym's first $2,000 sale within 7 days.
- "Fast beats free" — the only thing that beats free is fast; people pay for speed (FedEx, Uber, MVD line-skip).
- When two vehicles serve the *same* dream outcome, the dream cancels out — the other three drivers set the price ($50,000 vs. $5).

## Anti-patterns
- **Only inflating the top of the equation** (bigger and bigger claims): easy, lazy, least unique. Ignoring time delay and effort is where amateurs lose.
- **Selling the membership, not the outcome**: nobody wants a membership; they want to lose weight. Sell the destination.
- **Arguing with human nature**: "be right or be rich." Meditation beats Xanax on merit but Xanax wins on perceived value (lower time/effort cost) — monetize what people *value* to give them what they *need*.

## Worked Example
**Value Equation head-to-head — Meditation vs. Xanax.** Both promise the same dream outcome: relaxation, decreased anxiety, well-being. On a 0/1 scale across the four drivers, Xanax wins on likelihood (certainty of effect), time delay (works fast), and effort (swallow a pill vs. daily discipline). Same dream, radically different denominator — which is why Xanax is a multi-billion-dollar product and there are almost no billion-dollar meditation businesses. Same logic explains the supplement industry ($123B) being ~2x the health-club industry ($62B): identical perceived objectives, lower "costs" to the buyer.

## Key Takeaways
1. Run every offer through the Value Equation; your biggest wins come from shrinking the denominator (time and effort), not inflating claims.
2. Perception is the product — communicate likelihood, speed, and ease through messaging, proof, and guarantees.
3. Build offers by listing problems in insane detail (each core action spawns 4+ objections mapped to the value drivers), then reversing each into a "How to..." solution.
4. Solve *every* perceived problem — a single unaddressed objection ("but what about eating out?") kills sales you'd otherwise close.
5. Think divergently: generate many delivery vehicles per problem before you converge, so the final offer is one nobody can compare to.

## Connects To
- **Ch 2**: The premium price is only defensible because the Value Equation makes the offer feel like "money at a discount."
- **Ch 4**: Trim & Stack becomes the value-stack; guarantees directly raise Perceived Likelihood of Achievement, and scarcity/urgency compress felt Time Delay.
- **Leads bonus (ch12-ch13)**: "The pain is the pitch" — articulating problems is the input to lead-generating hooks.
