# Chapter 7: Attraction Offers

## Core Idea
Attraction Offers turn eyeballs into customers by handing over something free or discounted so the price-versus-value math is undeniable to a stranger — then recovering (and multiplying) that cost through the offers that follow. Free/discount/$1 live on one continuum; the greater the discount, the better the deal, and free is the greatest of all.

## Frameworks Introduced
- **Win Your Money Back**: Customer pays now; if they hit a goal or complete required actions within your rules, they get the money back as cash or store credit. "If you do X within Y time within Z rules, you can get it free."
  - When to use: businesses where the customer must put in continuous effort to get the result (fitness, coaching, skills, B2B challenges).
  - How: pick criteria that are (1) easy to track, (2) actually produce the result, (3) advertise your business (posts, tags, referrals, reviews). Make meetings/check-ins part of the criteria — each is an upsell slot. About halfway through, privately tell them they've already "won" to lower anxiety and keep them longer. Apply won credit toward something more expensive, spread over time (never free months up front).
  - Why it works: 100% discount = steepest possible incentive; many won't qualify, those who do stay if you have an upsell, and their before/afters advertise for free. The real money is people who SUCCEED and buy again — not people who fail. Only run it if your refund rate is under 5%.
- **Giveaway**: Advertise a chance to win a big Grand Prize for contact info + qualifying actions; after one winner, offer everyone else the same thing at a discount ("participation trophy").
  - When to use: to generate many qualified leads who've already shown interest in your most expensive product.
  - How: (1) make the Grand Prize the thing you want everyone to buy, with a real monetary anchor value; (2) build a promotional offer = core offer + discount/bonus, priced with a 10-30% margin discount off retail; (3) collect contact info + eligibility + qualifying actions; (4) put it on a 3-7 day deadline with daily hype; (5) announce ONE winner publicly, privately tell everyone else they "qualified," with a second deadline to claim. Give two prizes (referrer wins if their referral wins) to double leads.
  - Failure mode: weak Grand Prize = no leads. If nobody bites, the prize wasn't grand enough (event tickets flopped; a $50,000 equipment bundle + a year of product crushed).
- **Decoy Offer**: Advertise a cheap/free basic version; when leads engage, present it side-by-side with a far superior premium offer and emphasize the premium.
  - When to use: when your ad-generated leads are too expensive and you need to close nearly everyone who shows.
  - How: strip the decoy (fewer components, older models, no guarantee); make the premium as awesome as possible so the contrast is huge. If forced/asked to present the decoy, ask "Are you here for free stuff or lasting results?" — "results" jumps you to premium. Advertise benefits/dream outcome, not features.
- **Buy X Get Y Free**: Sell one thing and give others free — reframing a discount as a more attractive free offer. "Buy 1 pair get 2 free" costs the same as buying 3, but free pulls more interest than a discount.
  - When to use: products/durations that make sense to buy more of; recurring businesses; fast-cash pushes to existing customers.
  - How: permanently raise price to absorb the giveaway (don't lie — actually raise it). Give more free than paid ("buy 1 get 2," not "buy 2 get 1"). Free things can differ from paid things and cheaper-more can beat expensive-fewer.
- **Pay Less Now or Pay More Later**: Offer a choice — pay full price later (only if satisfied) OR a discounted price now with bonuses. Combines delayed payment + conditional guarantee.
  - When to use: to advertise "free," get the card on file, and remove all risk from the customer.
  - How: promise a clear yes/no, measurable result deliverable inside your timeframe; make the guarantee conditional on qualifying actions (attendance, data). Pay-Now = 20-50% discount + bonuses. Tune: too many pay-later → discount pay-now more; >10% cancel → you overpromised, conditions too loose, or price too high.

## Key Concepts
- **Store credit vs. cash back**: Same take-rate in testing, so offer store credit (pair with an unconditional satisfaction guarantee if still calling it "free").
- **Promotional offer**: The discounted core offer everyone-but-the-winner qualifies for in a Giveaway.
- **Price anchor**: The Grand Prize / retail value that makes the discounted price feel huge (a 10% discount off retail can read as a 64% cost-to-value gap).
- **Qualifying actions**: Steps entrants take (post, attend, refer) that both filter for interest and advertise the offer.
- **Conditional satisfaction guarantee**: Customer can cancel billing only if they met the terms — "they can't say you suck if they never try it."
- **Cost-to-value framing**: Compare value delivered to price paid, not price to price, to make the deal feel enormous.
- **Free Goodwill Offer**: Give value expecting nothing back (Hormozi's book-review ask) — reciprocity as its own attraction mechanism.

## Mental Models
- Treat "free/discount/$1" as interchangeable dials on one continuum — swap them to fit the channel and audience.
- Discount offers get FEWER leads but HIGHER show-up rates than free offers — use discounts when a no-show is costly (doctors, dentists, lawyers).
- "Make everyone a winner" in private: sell as if they must earn it, then quietly credit them as if they already won — surprise + gratitude primes the upsell.
- Every required meeting/call is an offer slot, not just a check-in.

## Anti-patterns
- **Running Win Your Money Back with a >5% refund rate**: fix the product first, or you'll refund your way out of business.
- **Giving all winnings as free months up front**: people fall off when they pay nothing — keep skin in the game via a long-spread discount.
- **Treating the decoy as the goal**: it only has to get leads to engage; losing money on it is fine because you close them later.
- **Selling Buy X Get Y Free you can't deliver**: taking a year of payments in a month then spending the delivery cash = broke and possibly illegal. Budget to service the full term.
- **Under-grand prizes**: a giveaway with a boring prize is just a failed ad.

## Worked Example
Danny's gym (the origin of Win Your Money Back): a reluctant prospect proposed "I give you $500, you train me 8 weeks, and if I hit my goal I get my money back — but you can use my results to market." Danny figured the guy wouldn't buy anyway, so he said yes. The customer hit the goal, then used the $500 back as credit to buy MORE training, and his before/after photos brought in 13 referrals. Danny rolled it out to everyone: better results, customers loved the offer, and the free advertising pulled in friends and family. Hormozi adopted it across private/group training and nutrition, then moved it from existing customers into paid ads — CAC dropped, leads exploded. The mechanics that made it pay: most don't qualify, qualifiers stay because there's an upsell, winnings apply to a more expensive package spread over 12 months ($600 credit = $50/mo off a $200/mo service, so they pay $150/mo and stay engaged).

## Key Takeaways
1. Discounts make anything a great deal to a stranger because they understand price but must take your word on value — free is the max lever.
2. You make money on "free" by having a next offer: the Attraction Offer covers CAC + delivery, the upsell prints the profit.
3. Win Your Money Back pays on the winners (who buy again), not the losers — the more results you deliver, the more you make.
4. Build advertising INTO your offer criteria (posts, referrals, before/afters) so customers acquire more customers.
5. Free pulls more leads; discount pulls higher show-rate — pick by your no-show cost.
6. Always get the card on file (Pay Less Now/Later) and always have a next thing to sell.

## Connects To
- **Ch 6**: Attraction Offers are Stage I of the Money Model — cover the cost of getting the customer so CFA can start.
- **Ch 8 (Upsells)**: Every Attraction Offer reveals a problem; the upsell (applied store credit, supplements, membership) is where the profit actually lands. Win Your Money Back's rollover of winnings → Rollover Upsell.
- **Ch 9 (Downsells)**: Pay Less Now/Pay More Later reappears as a downsell for physical/one-time products; Win Your Money Back's criteria feed the Trial With Penalty.
- **Ch 10 (Continuity)**: Giveaway/Pay-Later discounts spread over the longest agreement roll straight into a subscription.
- **Offers Ch 3 (Value Equation)**: Attraction Offers engineer value >> price; the Value Equation is how you inflate perceived value so the discount reads as a giveaway.
