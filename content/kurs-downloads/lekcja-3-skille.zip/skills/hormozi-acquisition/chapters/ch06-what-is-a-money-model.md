# Chapter 6: What's A Money Model?

## Core Idea
A Money Model is a deliberate sequence of offers that makes so much profit from one customer in the first 30 days that acquiring the next customer becomes self-funding. Win that and cash stops being the thing that limits how fast you grow.

## Frameworks Introduced
- **Money Model (definition)**: A sequence of offers presented in a specific order, each solving the next problem the previous purchase reveals. "If you offer the right thing when customers realize they need it, you can make as many offers as you like."
  - When to use: always — every business already has one, good or bad. The choice is whether you design it or let it happen by accident.
  - How: chain the four offer types — Attraction (get customers) → Upsell (spend more) → Downsell (turn no into yes) → Continuity (keep buying).
  - Why it works: each offer solves a real problem the customer just discovered, so the sale feels like service, not pressure. Hard selling is for weak products.
- **Client Financed Acquisition (CFA)**: Make enough gross profit from a new customer in ~30 days to pay for getting AND servicing that customer at least twice over — so the customer funds their own acquisition plus the next customers.
  - When to use: as the survival test for any acquisition engine. It is the difference between growing fast and slowly bleeding out.
  - How: front-load cash via Attraction + Upsell + Downsell inside the first 30 days instead of waiting on the slow drip of profit from many customers.
  - Failure mode: a "bad Money Model" costs more to get a customer than it makes — the death spiral (cut ads → fewer customers → float on loans/credit → sell equity → lose it all).
- **The 30-Day Cash Test**: Two options for any acquisition. Option 1: wait years to make your money back and pray you don't run out of cash. Option 2: get paid fast and grow as much as you please. A good Money Model is always option 2.
  - How: measure payback window in days, not years. A $100 CAC returning $500 profit is only a great business today if the payback is fast; over two years it starves a bootstrapped company.

## Key Concepts
- **Attraction Offer**: Turns strangers into customers (something free or discounted).
- **Upsell Offer**: Gets existing customers to spend more (whatever you offer next).
- **Downsell Offer**: Gets a "yes" from someone who just said "no."
- **Continuity Offer**: Keeps people paying again and again (recurring value for recurring payment).
- **Gross profit**: The margin on a customer after cost to deliver — the pool CFA must fill inside 30 days.
- **Payback window**: How long until a customer's payments recover their acquisition + delivery cost. Shorter = faster growth.
- **$100M Money Model**: Makes more profit from ONE customer than it costs to get and service MANY customers in 30 days — removes cash as a growth limiter entirely.
- **Sequence of offers**: The core structure — many offers, specific order, each triggered when the customer feels the problem.

## Mental Models
- Think of a Money Model as the rental-car counter: you came for a $19/day car and left at $100/day, happy, because each add-on solved a real problem at the moment you felt it.
- Use the compounding lever: double customer value AND double volume AND double speed → grow 8x faster (2×2×2). Triple each → 27x. Small changes to the model, outsized change to growth.
- "We don't get customers to make a sale, we make sales to get customers." The sale is the acquisition channel, not the finish line.

## Anti-patterns
- **One-offer business**: "You barely have a business — you have a front end." Selling only the first thing leaves the majority of available profit (which lives in offers 2, 3, 4) on the table.
- **The slow-drip model**: Relying on thin profit from many customers to eventually fund one new customer — only works if you already have tons of cash or investors. Starves bootstrappers.
- **Hard selling a weak product**: If they don't want it, find someone who does. It's a numbers game.
- **Copying "what they do" verbatim**: Some models fit some businesses better. Design your own; don't clone.

## Worked Example
Hormozi's gym model, reverse-engineered on a $25,000 mentor call. He advertised a Free 6-Week Challenge until ~20 leads/day at $5/lead. Half showed to appointments; he closed half of those into a $600 program → ~25% of leads became customers, plus ~$80 supplement profit each = ~$680 per customer, all before opening the gym doors. The mentor's math: "$1 in, $34 out, in 48 hours." Then the back end: weeks later he offered the $600 back as credit if they signed a year membership; two-thirds converted → a full gym plus ~$20,000/mo in memberships, for $3,000 down. Rinse and repeat, opening a new location every six months with no debt. That is CFA: the first purchase funds acquisition, the upsell/rollover funds recurring revenue, all inside 30 days.

## Key Takeaways
1. Every business has a Money Model — designing it deliberately is what separates scaling from surviving.
2. The bar (good model): more 30-day profit per customer than the cost to get + service them. The dream ($100M model): fund many customers off one.
3. Speed of cash beats size of cash. Fast payback compounds; slow payback starves.
4. Chain all four offer types — each covers a gap the previous one leaves (few customers → low spend → lost "nos" → no recurring cash).
5. Solve a problem, and another appears; offer to solve that one too. That is the whole engine.
6. Refund without friction, obey the law, be transparent — reputation can't file for bankruptcy.

## Connects To
- **Ch 7-10**: The four offer types in order (Attraction, Upsell, Downsell, Continuity) — the levers this chapter frames.
- **Ch 11**: Assembling the offers into a staged Money Model (Get Cash → Get More Cash → Get The Most Cash).
- **Offers Ch 3 (Value Equation)**: Attraction Offers manufacture the "great deal" (value >> price) that makes strangers buy; the Value Equation is how you inflate perceived value beyond the discount.
- **Offers Ch 1-2 (Grand Slam Offer)**: Win Your Money Back was Hormozi's first Grand Slam Offer — the Money Model is the Grand Slam Offer extended across a sequence.
- **Leads (ch12-13)**: The Money Model is what makes paid advertising work — CFA lets you outspend everyone because customers fund the ad budget.
