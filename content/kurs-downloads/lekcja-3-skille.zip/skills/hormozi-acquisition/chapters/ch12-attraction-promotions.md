# Chapter 12: Attraction Promotions — Premium Promotions (Presenting Your Grand Slam Offer On Its Own)

## Core Idea
To pull cold prospects toward you, you wrap your Grand Slam Offer in a promotional layer (Premium, Free, or Discount) that enhances attractiveness without changing the offer itself. This chapter covers the framing plus the first wrapper: Premium Promotions, which present the Grand Slam Offer at full price on its own to sell the client the single best outcome available.

## Frameworks Introduced
- **Promotional Wrapper (Premium / Free / Discount)**: The three ways to present one core Grand Slam Offer to a cold market. The offer is the gift; the promotion is the wrapping paper.
  - When to use: Any time you enter a cold market and must give people a reason to move toward you (answer "what's in it for me?").
  - How: Keep the core offer fixed → choose Premium (full price, standalone), Free, or Discount as the presentation layer → match the wrapper to your market maturity and cash position.
  - Why it works / failure mode: A wrapper makes the SAME contents more inherently attractive (newspaper vs. Chanel bag). Failure mode: changing the offer instead of just enhancing its presentation.
- **Get Flow → Monetize Flow → Then Add Friction**: Sequencing rule for building demand before extracting margin.
  - When to use: Entering any new market or launching a new acquisition channel.
  - How: Generate demand with a low/free front end first → prove you can monetize it → only then add friction and raise prices.
  - Why it works / failure mode: Demand is the scarce resource; monetization is solvable once flow exists. Failure mode: "cart before the horse" — optimizing price/friction before any flow exists.
- **Premium Promotion (Standalone Full-Price Offer)**: Sell one expensive, high-value result at full price with no incentive.
  - When to use: You already have a proven sales process OR cash to burn learning one, and you want quality over volume.
  - How: Have a genuinely valuable Grand Slam Offer → build a selling process that demonstrates that value → filter with copy so only serious buyers apply ("Apply & book a call to see if you qualify") → close a small number at high ticket.
  - Why it works / failure mode: Infinite-upside math (see Mental Models) makes low volume far more profitable. Failure mode: launching premium with no proven process and no cash cushion — most expensive cost-per-lead, least room for error.

## Key Concepts
- **Grand Slam Offer**: The core high-value offer (from $100M Offers) that every promotion wraps; the promotion enhances it, never replaces it.
- **Premium Promotion**: Presenting the Grand Slam Offer at full price, standalone, with no discount or free hook.
- **Infinite Returns / Infinite Upside**: You can only price down to $0, but you can price infinitely up — so the leverage is always on the high side.
- **Skim vs. sift**: Premium marketing "skims the cream" (highest-quality buyers) instead of sifting through low-quality volume ("the poo").
- **Operational drag**: The cost of servicing many low-quality customers; premium reduces it by delivering fewer, better clients.
- **Ticket size**: The dollar value of one sale; premium's core advantage is how large a ticket you can sell ("nothing below $0, but you can go infinitely higher").
- **Filtering copy**: Pre-offer copy that self-selects qualified, price-tolerant buyers before an unattractive "apply to qualify" CTA.
- **Specificity**: The edge in copy — "cleaning the bathrooms yet again" beats "working hard"; premium demands it because there's no discount to push fence-sitters over.

## Mental Models
- **Use Premium when you have a proven sales process or cash to learn one; use a Free/Discount wrapper when you're new, low-volume, or acquisition cost is higher than you can bear.**
- **Use the $25,000/hr budget, not the $6.75/hr budget.** A high-ticket offer lets you outbid competitors for the same traffic because each sale is worth vastly more — you don't need the volume.
- **Use premium as the SECOND offer after a free first offer** once you've already demonstrated value; it converts because trust already exists.
- **Use free/discount when your copy isn't dialed in** — the offer pushes fence-sitters over the edge and forgives weaker copy; premium gives you no such margin for error.

## Anti-patterns
- **Leading with premium when broke or unproven**: Highest cost per lead, longest time to break even, least room for error. If you lost everything, you'd start with free/discount, not premium.
- **Changing the offer to make a promotion**: The promotion enhances the Grand Slam Offer; it must not alter what's inside the box.
- **Chasing volume with a straight premium offer**: Least efficient way to capture a marketplace — you must hit far more eyeballs per bite. Wrong tool if market-share/volume is the goal.
- **Weak, generic copy on a premium offer**: Without discount leverage, only specificity and a truly irresistible package (bonuses, guarantees, premium support) will close.

## Worked Example
**The $50,000 burger → Premium math.** A hedge-fund manager making $50M/year (~$25,000/hr) buys a gold-and-caviar burger for $50,000. To him it costs two hours of work — the same two hours a $6.75/hr worker spends to afford a $13.50 burger, fries, and soda. Same relative cost, wildly different absolute ticket. Translate to advertising: Business #1 makes $50 profit/sale and must close 190 people to net $9,500. Business #2 makes $9,500 profit/sale. Take those same 190 leads and pitch them the $10,000 offer instead — close ~5%:

- 5% × 190 = 9.5 sales
- 9.5 × $9,500 = $90,250
- vs. 190 × $50 = $9,500
- $90,250 / $9,500 = **9.5× more profitable**

Despite far lower volume, the premium offer earns 9.5× more AND you service ~10 clients instead of 190. That is the power of premium — but only with (1) something genuinely valuable to provide and (2) a selling process that demonstrates the value.

## Key Takeaways
1. The offer is the gift; Premium/Free/Discount is the wrapping paper — enhance, never change, the Grand Slam Offer.
2. Sequence every market: Generate Flow → Monetize Flow → Add Friction. Never reverse it.
3. Price has infinite upside and a $0 floor — lean on the high side; you don't need the volume.
4. Premium is standalone and profitable: with existing clients you can 3–5× prices without changing the service.
5. Premium delivers fewer, higher-quality, easier-to-serve customers and simplest math — but demands proven sales skill and cash tolerance.
6. If you're new, low-volume, or acquisition-cost-strapped, wrap the premium offer in free or discount first, prove results, then restructure to premium.
7. Premium works best as the second offer after a value-demonstrating free first offer.

## Connects To
- **Ch 1–5 ($100M Offers)**: The Grand Slam Offer and Value Equation are what every promotion wraps; premium is the purest expression of a high-value offer sold on its own. Bonuses, guarantees, and premium support (from Offers) are what make a full-price premium package "still feel like a steal."
- **Ch 7 (Attraction Offers, Money Models)**: Premium is the standalone/core offer; the Free and Discount wrappers in Ch 13 are the attraction layers that feed it.
- **Ch 13 (Free & Discount Promotions)**: The two other wrappers — used when you're new, need volume/cheap leads, or want a two-step sale into a premium back end.
- **Infinite Returns**: The pricing asymmetry ($0 floor, infinite ceiling) that justifies leading with a high ticket.
