# Chapter 13: Free & Discount Promotions

## Core Idea
Free is the most powerful offer of all time because it maximizes response — it gets the most leads per eyeball at the lowest cost — and it still profits when you monetize downstream and let friction skim the cream. Discount promotions are its regulated, cash-collecting cousin: give away a splintered piece of your offer at a massive discount to capture a card on file and set up a two-step sale into a premium back end.

## Frameworks Introduced
- **Free Promotion (Value in Advance)**: Give something away for nothing to maximize lead volume and minimize cost, then monetize downstream.
  - When to use: Entering a new market, need maximum volume in a small/local pond, want the fastest test of whether anyone wants your thing, or want cheap testimonials and referrals.
  - How: Give away a valuable "thing" free → capture the flood of leads → apply friction to skim quality → monetize on the back end.
  - Why it works / failure mode: The penny gap — 9× more people take "free" than "$0.01." Failure mode: if a free offer flops, prospects (1) don't want the thing, (2) don't believe you, or (3) aren't seeing it (wrong pond / targeting). A too-good free offer triggers the "Why?" objection you must answer.
- **Friction Ladder (5 levers to convert volume into quality)**: Deliberately add friction to raise lead quality when free brings too much volume.
  - When to use: Free attracts more prospects than you can operationally handle, or quality is too low.
  - How: Add one or more of — (1) Increased qualifications (must be 25+, employed, homeowner), (2) more/heavier info requirements (20-question app; phone/income asks are "heavier" than first name; open-ended > multiple choice), (3) more steps (5-step form vs. one-step opt-in), (4) forced consumption (watch a 40-min video before any CTA), (5) advertisement length (2-hour video vs. 30-sec).
  - Why it works / failure mode: More hoops = fewer, higher-quality people. Failure mode: over-frictioning past the "sweet spot" — you lose lazy whales along with the weirdos.
- **Free Money Math**: Judge campaigns by total dollars, not by the qualified-lead percentage that "feels" better.
  - When to use: Deciding between a high-volume/lower-quality free campaign and a lower-volume/higher-quality one.
  - How: Compare total qualified leads produced per ad spend, not the qualification rate.
  - Why it works / failure mode: Raw volume with friction usually nets more total sales. Failure mode: chasing a prettier qualification percentage while producing fewer actual qualified leads and less profit.
- **Massive Discount (50%+)**: A perceived-value discrepancy large enough to move people who otherwise wouldn't act.
  - When to use: Regulated markets where free is restricted, or well-understood services (dentists, chiropractors, gyms, haircuts) where people know the normal price.
  - How: Splinter your offer → discount ONE small component 50%+ (never the core offer) → collect a card on the phone → set the two-step sale.
  - Why it works / failure mode: Only big discounts drive real behavior. Failure mode: marginal 5–25% discounts just cut margin without moving anyone; discounting the CORE offer trains customers to buy only on sale.
- **Two-Step Sale (the biggest reason to discount)**: A small paid front-end transaction that captures the card and sets up a seamless premium upsell.
  - When to use: You want to eliminate no-shows, build initial trust, and make future upsells frictionless.
  - How: Ad → opt in → phone call for a $19 promo, set appt → prospect shows up (85–90%+ show for things they pay for) → gets value → schedules follow-up → sold the premium program (e.g., $2,100) with the card already on file.
  - Why it works / failure mode: Paying customers show up; a card on file kills "I forgot my card" friction (the Amazon one-click / Disney wristband effect). Failure mode: treating discount buyers as "customers" instead of qualified leads.

## Key Concepts
- **Free Promotion**: Giving value in advance for nothing to maximize response and minimize lead cost.
- **Penny Gap**: Dr. Dan Ariely's finding — 9× more people take a free Hershey kiss than one priced at a penny; the jump from $0.01 to free is enormous.
- **Friction**: Any hoop (qualification, info, steps, forced consumption, ad length) that trades volume for lead quality.
- **Free Money Math**: Evaluating campaigns by total qualified leads/dollars, not by qualification percentage.
- **Freebie-Seeker Myth**: The belief that free attracts only broke, non-buying prospects — empirically false on close rate.
- **Discount Promotion**: Massively discounting a splintered piece of your offer to acquire a customer, not to fund the business.
- **Two-Step Sale**: A cheap paid front end that captures a card and paves the way for a premium upsell.
- **Splintering**: Carving off a tiny valuable component to discount, keeping the core offer at full price ("not the whole farm").
- **Card on File**: The captured payment method that makes upsells "smooth as butta" and eliminates no-shows.
- **Bargain Hoppers**: Discount-seekers (the Groupon problem) — a structuring failure, not a customer-quality failure.

## Mental Models
- **Use Free when you need maximum volume and cheapest leads in a limited pond; use Discount when free is legally restricted or the service is well-understood.**
- **Use friction to skim, not to fund.** Free maximizes volume; add friction to find the sweet spot between weeding out weirdos and keeping lazy whales.
- **Use discount money as an acquisition offset, never as the business model** — it "liquidates acquisition costs" but never funds marketing.
- **Use a two-step discount when show-up and no-shows matter** (doctor's time, high-cost service slots) — paid front ends get 85–90%+ show rates.
- **Judge by dollars, not feelings** — the campaign that "feels" more qualified often produces fewer total qualified leads.

## Anti-patterns
- **Believing "free brings broke people"**: Four independent split tests (10 markets each) showed identical close rates and ticket sizes between free and non-free respondents. What differed: free cut lead cost by 5×+.
- **Marginal discounts (5–25%)**: Too small to change behavior; just erodes margin.
- **Discounting the core offer**: Trains customers to buy only on sale (works only for clothing-retailer "inflate then discount" models — a double-edged sword).
- **Over-frictioning**: Push past the sweet spot and you lose otherwise-qualified "lazy whales."
- **Ignoring the "Why?"**: An unbelievably good free offer ("give me $100, I'll give you $1,000 back") gets zero response without a credible reason. A famous marketer ran exactly that newspaper ad for years — nobody ever called.
- **Treating discount buyers as customers**: They're qualified leads to be upsold, not the endpoint.

## Worked Example
**Free Money Math — which campaign wins?**
- Campaign #1: Spend $1,000 → 500 leads → half unqualified (250), half qualified (**250 qualified**).
- Campaign #2: Spend $1,000 → 200 leads → 80% qualified (**160 qualified**), 20% unqualified (40).

The team feels better about #2 (80% qualification rate looks clean). But by pure dollars and cents, #1 wins — 250 qualified leads for the same $1,000 beats 160. You provide value without overextending, then let friction skim the cream off the higher volume. That is how you harness the power of free: don't optimize the prettier percentage, optimize total qualified leads per dollar.

**Two-Step Discount — the $19 → $2,100 ladder.** Give away a heavy-metals test consultation for $19. Ad → opt in → phone call collects the $19 and the card, sets the appointment → prospect shows up (paid, so ~85–90% do) → gets real value → schedules a follow-up → at the second appointment, upsold into a $2,100 10-week detox program with the card already on file. The $19 never funds the business; it buys a qualified, card-on-file lead and a near-guaranteed show.

## Key Takeaways
1. Free is the most powerful offer ever — highest lead volume, lowest lead cost — because response, not quality, is the scarce resource up front.
2. The penny gap is real: dropping from $0.01 to free can 9× your leads.
3. Free doesn't lower quality — four split tests proved identical close rates; it only slashes lead cost (5×+).
4. Convert free's volume into quality with the 5-lever friction ladder; find the sweet spot, don't over-friction.
5. Judge campaigns on total qualified leads per dollar (Free Money Math), not on the qualification percentage that feels tidy.
6. Use massive discounts (50%+) only; marginal discounts just bleed margin. Splinter and discount a piece, never the core.
7. The real prize in discounting is the two-step sale: capture a card, kill no-shows, and upsell a premium back end seamlessly.

## Connects To
- **Ch 12 (Premium Promotions)**: Free and Discount are the other two wrappers around the same Grand Slam Offer; premium is the ideal back-end that a free/discount two-step sale feeds into.
- **Ch 1–5 ($100M Offers)**: Free and discount give margin for error on copy that a premium offer can't — but the underlying Grand Slam Offer and Value Equation still do the heavy lifting; answering "Why?" on an unbelievable free offer is core offer-credibility work.
- **Ch 7 (Attraction Offers, Money Models)**: Free and discount ARE the attraction offers — the front-end lead generators that get people who otherwise wouldn't respond, to respond.
- **Advanced Monetization (Section IV, forward reference)**: Intelligent offer structuring is what resolves the freebie-seeker / bargain-hopper "problems" by auto-qualifying prospects into core-service customers.
- **Get Flow → Monetize Flow → Add Friction (Ch 12)**: Free and discount are how you generate the initial flow before monetizing and adding friction.
