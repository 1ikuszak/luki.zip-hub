# Chapter 9: Downsell Offers

## Core Idea
A Downsell is any offer you make after someone says "no" — you tweak how they pay or what they get to find the highest-value solution their budget allows. No means no to THIS offer, not to all offers. The extra yeses explode 30-day profit from the same lead flow.

## Frameworks Introduced
- **Payment Plan Downsell** (changes HOW they pay): Offer the same product at the same total price, but spread the cost — some now, the rest on scheduled payments.
  - When to use: when "it costs too much" really means "it costs too much up front" (which it usually does). Gets more buyers like a discount, but preserves full price.
  - How: a descending 7-step ladder, stop the moment they buy — (1) Reward paying in full instead of punishing paying over time (present the interest-included price, then offer a prepay discount + anchor); (2) offer 3rd-party financing → credit card → layaway; (3) half now, half on next paycheck ("What's the most you can put down today?"); (4) temperature check ("scale 1-10, how bad do you want this?" — 8+ keep going, 7- switch to a Feature Downsell); (5) split into thirds; (6) evenly spread over the service term; (7) offer a Free Trial (next chapter).
  - Why it works / failure mode: makes money when more customers buy AND complete payments; LOSES the most when people who'd have paid in full take a plan and cancel early. So watch that paid-in-full count doesn't drop. Align charges to paycheck dates and re-run declines same-day to recover ~1/3.
- **Trial With Penalty** (changes HOW they pay): Customer tries the product free so long as they meet your terms; they only pay if they DON'T meet them.
  - When to use: as a downsell for recurring products/services where the customer must do work to get results. (Mirror image of Win Your Money Back — there they earn money back; here they avoid a fee.)
  - How: always get a credit card ("What card do you want to use?" — "that's just how we've always done it"). Get commitment to stay long-term IF it works. Explain fees AFTER getting the card (less resistance), with initials next to fee clauses. Make check-ins mandatory (they're upsell slots). Criteria = the same activation/retention actions as Win Your Money Back. Break the fee up per-missed-item rather than one lump. Just call it a "Free Trial."
  - Why it works: trial users actually USE the product and get value, so they convert far better than a normal free trial. Turns "3 of 10 sold" into "6 of 10" by rescuing the nos.
- **Feature Downsell** (changes WHAT they get): Lower the price by changing what's included — lesser quantity, lower quality, cheaper alternative, or cut a feature — NOT by discounting the same thing.
  - When to use: when you want to charge less without devaluing via a discount, and to make customers "re-upsell" themselves onto the original offer.
  - How: remove features from HIGHEST to lowest value. Removing a high-value feature (e.g., the money-back guarantee) and dropping price only a little makes people feel the loss and jump back to the full offer. Name combinations aspirationally (First Class → Business → Economy; "The Whale Package" ... "The Minimum"). After two downsells, temperature-check (1-10); 8+ → start Payment Plan Downselling (alternate the two and you become very hard to refuse). Barter discounts for reviews/testimonials/referrals.

## Key Concepts
- **Downsells are trades**: If you give something, get something — never just drop price.
- **Discounting ≠ downselling**: Dropping price for the same thing is discounting; downselling changes payment terms or contents.
- **Temperature check**: "Scale 1-10, how bad do you want this?" — 8+ means keep working payment options; 7 or below means find a different (feature) fit.
- **Seesaw Downselling**: A simpler payment-plan script — "giant monthly payments or tiny ones?" → prepay for a discount and zero payments → adjust the down payment until the monthly rate feels good.
- **Business terrorists**: People who demand to pay less for the exact same thing — "I don't negotiate with terrorists." Offer a payment plan (pay less now) or a feature downsell (pay less overall), never a naked discount.
- **"The Minimum" package**: The cheapest named combination — implies they should get at least that, and lets you use "so nothing more than the minimum?" to say-no-to-say-yes.
- **Billing cadence → churn**: Profitwell data across 14,000 businesses — monthly billing = 10.7% monthly churn, quarterly = 5%, annual = 2%. Starting high (bigger, fewer payments) both fronts cash AND retains longer.

## Mental Models
- Think "100 ways to offer the same product," not "100 products to offer."
- "Personalize, don't pressure": offer more of what they like, less of what they don't, at a matching price — refusing to re-offer would be the offensive thing.
- Payment Plan and Feature Downsells are alternating tools — bounce between "change how you pay" and "change what you get" until you land a match.
- A free orientation converts DIY feature-downsells: refuse the Done-For-You, come to a free orientation, ~half show, nearly all buy the DIY product (supplements).

## Anti-patterns
- **Dropping price to save a sale in the moment**: customers talk; someone finding out they paid more "just because" burns trust and is an ethics problem. Test prices deliberately, never reactively.
- **Putting would-be-full-payers on payment plans**: if paid-in-full count falls after adding plans, the plan is cannibalizing your best cash.
- **Nickel-and-diming trial fees**: a small fee isn't worth a 1-star review — don't bill non-starters; you make money by converting them, not by penalties.
- **Negotiating with "business terrorists"**: same thing for less = never.

## Worked Example
The Feature Downsell origin (2019). A friend tripled his close rate from 25% to 75% AND sold more of the main thing — without payment plans or discounts. His move: when he got a price objection, he offered to cut the money-back guarantee for a lower price — "If you don't want the option to get your money back, you can pay less. Or keep your guarantee — which would you prefer?" Customers, forced to see the guarantee's value only once it was removed, said "Screw it, I'd rather keep the guarantee." The numbers: before, 100 calls → 25 bought the one full-price option. After, 35 bought the main thing AND 40 took the downsell — higher full-price buyers, higher total close rate, more up-front cash, all from making the removal of a high-value feature reveal its worth.

## Key Takeaways
1. "No" is data, not rejection — it tells you what to offer next. Make another offer.
2. Change how they pay (payment plan / trial) to keep price whole; change what they get (feature) to lower it. Never discount the identical thing.
3. Start high and work down — bigger-fewer payments front cash AND cut churn.
4. Trial With Penalty beats a normal free trial because terms force real usage, which drives conversion.
5. Remove features highest-value-first so customers re-sell themselves on the full offer.
6. Alternate payment-plan and feature downsells (with 1-10 temperature checks) to become nearly impossible to refuse.

## Connects To
- **Ch 6**: Downsells are Stage II of the Money Model (with upsells) — they lift 30-day profit by converting nos, tightening CFA.
- **Ch 7 (Attraction)**: Trial With Penalty criteria are lifted straight from Win Your Money Back; Pay Less Now/Pay More Later is used here as a downsell for physical/one-time products.
- **Ch 8 (Upsells)**: Named upsell bundles get "peeled" into Feature Downsell tiers; the "say no to say yes" close reappears in "The Minimum."
- **Ch 10 (Continuity)**: Payment-plan cadence data foreshadows the churn/continuity discussion; feature-downsell elements build continuity bonuses.
- **Offers Ch 5 (Guarantees)**: The guarantee-as-removable-feature move depends on the guarantee library from the Offers book.
