# Chapter 4: Enhancing Your Offer — Scarcity, Urgency, Bonuses, Guarantees, Naming

## Core Idea
Once the core offer exists, five outside-the-product levers shift the demand curve in your favor without changing what you deliver: scarcity (limit quantity), urgency (limit time), bonuses (widen the price-to-value gap), guarantees (reverse risk), and naming (the MAGIC formula). These positioning forces are often more powerful than the offer itself.

## Frameworks Introduced
- **Scarcity (limit quantity)**: Decrease supply/perceived supply to raise price and, via exclusivity, demand. Fear of loss > desire for gain.
  - When to use: year-round, especially high-ticket tiers and upsells.
  - How — three types: (1) Limited seats/slots (Total Business Cap, Growth Rate Cap "X clients/week," Cohort Cap), (2) Limited bonuses, (3) Never available again. Physical products: always sell out and *announce* the sellout (social proof). Honest Scarcity: publicly state real capacity ("81% full") — the most ethical version.
- **Urgency (limit time)**: A function of time, not quantity. Deadlines drive decisions.
  - How — four types: (1) Cohort-based rolling urgency ("sign up today or wait for Monday's kickoff"), (2) Rolling seasonal urgency (same promo, new seasonal wrapper + real countdown), (3) Pricing/bonus-based urgency (the promo, not the service, expires), (4) Exploding opportunity (arbitrage that decays with time).
- **Bonuses**: A single offer is worth less than the same offer broken into components and stacked as named bonuses.
  - When to use: to close without discounting (discounting teaches customers your price is negotiable).
  - How: 1-on-1, ask for the sale first; if yes, reveal bonuses as a "wow"; if no, add a bonus matching their specific objection, then ask again ("fair enough?"). Each bonus: benefit-driven name, price tag, addresses a specific obstacle, solves the *next* problem. Bonus value should eclipse the core offer's price. Advanced: other people's products/services as bonuses (free to you, exposure for them, plus affiliate commissions).
  - Why it works: increases the price-to-value discrepancy by adding value instead of cutting price — anchor to the core price, then stack until the rubber band snaps.
- **Guarantees**: Reversing risk is the #1 way to increase conversion (Fladlien saw 2-4x from guarantee quality alone). Power comes from the conditional: "If you don't get X in Y time, we will Z."
  - Four types: (1) **Unconditional** (no-questions-asked refund — strongest puller, best for lower ticket), (2) **Conditional** (terms/consumption requirements; aim for "better than money back"; embeds success actions), (3) **Anti-guarantee** ("all sales final," needs a compelling reason-why; for exclusive/once-seen-can't-unsee products), (4) **Implied** (performance/revshare/profit-share — "if I don't perform, I don't get paid").
  - How: stack guarantees (unconditional + conditional); name them creatively ("Club a Baby Seal Guarantee"); do the math, not emotion.
- **MAGIC Naming Formula**: **M**agnetic reason-why · **A**nnounce avatar · **G**oal (dream outcome) · **I**nterval (time) · **C**ontainer word (Challenge, Blueprint, Bootcamp, Intensive, Accelerator...).
  - How: use 3-5 of the 5 components, any order, punchy over complete. Optional rhyme/alliteration. Change the "wrapper," never the underlying offer.

## Key Concepts
- **Delicate Dance of Desire**: Supply and demand are inversely correlated; keep supply *under* the demand you generate to keep the customer base ravenous. "Desire is a contract to be unhappy until you get what you want" (Naval).
- **Hormozi's Law**: "The longer you delay the ask, the bigger the ask you can make. The longer the runway, the bigger the plane that can take off."
- **Fractal (80/20) demand**: Demand is non-linear — ~1/5 of prospects will pay ~5x. Skim the top of the pyramid, leaving pent-up demand.
- **The person who needs the exchange less has the upper hand** — real (or projected) indifference is a pricing/negotiation superpower.
- **Guarantee math**: Close 130% as many at 2x the refund rate (5%→10%) and you still net 1.23x. For a guarantee to lose, the sales lift must be 100% offset by refunds.
- **Wrapper vs. offer**: Naming/creative is the wrapper; the money model, price, and services underneath stay unchanged.

## Mental Models
- Use scarcity/urgency to control *supply*, not to change the product — "sell air for millions" via implied demand (why authorities and celebrities charge egregious rates).
- Add bonuses instead of discounting — position of strength and goodwill, not weakness.
- Prefer service/performance guarantees to start (all sales final, no refund fear, commits you to results); move to looser refund guarantees for volume as you get better.
- Treat naming as evergreen lead-gen: when an offer fatigues, change in order — creative → body copy → headline/wrapper → duration → free/discount enhancer → monetization structure (last resort). Once monetized, rarely change the machine.

## Anti-patterns
- **Discounting the core offer to close**: trains customers that prices are negotiable.
- **Weak, "or-what"-less guarantees** ("We'll get you 20 clients guaranteed"): no teeth. Give the "or we refund money + ad spend."
- **Over-ordering when using scarcity**: better to consistently sell out than fail to sell out and kill the scarcity effect.
- **Fake countdowns / phony deadlines**: destroys credibility; makes you look like every wannabe marketer.
- **Lazy/half-assed naming**: can ruin conversions; the same offer named well gets 2-10x response.
- **Guarantee as a crutch**: it enhances a good offer but cannot save a bad product or sales team — it just multiplies refunds.

## Worked Example
**Arnold's After School All Stars fundraiser (scarcity + urgency + bonuses live).** Donor George advised the CEO: "When demand increases, cut supply." They raised ticket price $15,000 → $25,000 *and* cut the number of tickets to 100 — raising an extra $1M before the event even started, with more-qualified attendees. Night total: ~$5.4M from 100 people ($54,000/head). Auction items were one-of-a-kind (never available again = scarcity + urgency); Arnold threw in bonuses when two bidders climbed high enough. Same physical products that wouldn't fetch $10,000 elsewhere sold for $100,000 — the products never changed, only the demand-supply framing did. **Bonus stack (Fladlien conditional guarantee):** on a $2,997 e-commerce course he promised "spend $X on ads using these methods and don't make money, I'll buy your store for $25,000." It drove ~$3M in extra sales; he paid out only 10 refunds ($250k) — the crazy guarantee generated $2.75M net.

## Key Takeaways
1. Keep supply under the demand you can generate — satisfy all desire and you kill the golden goose; the longer the runway, the bigger the ask.
2. Reverse risk aggressively — guarantees are worth as much design time as the deliverable itself; always state one boldly with a reason-why, and do the math before fearing refunds.
3. Stack the offer's components as named bonuses whose total value eclipses the price; add bonuses to close, never discount.
4. Layer scarcity and urgency onto bonuses and the core offer — but keep them honest, or lose credibility.
5. Name with MAGIC (3-5 components) and refresh the wrapper, not the machine, to get leads forever from the same offer.

## Connects To
- **Ch 3**: Bonuses and guarantees are Value Equation moves — tools/checklists beat trainings (lower effort), guarantees raise Perceived Likelihood of Achievement, urgency compresses felt Time Delay.
- **Ch 2**: Scarcity is the mechanism behind the premium-price / category-of-one thesis.
- **Money Models (ch06-ch11)**: "Monetize free and discounted offers" and the performance/revshare structures are developed there; MAGIC's Magnet component ("Free/88% off") feeds them.
- **Leads bonus (ch12-ch13)**: Naming = the key to evergreen lead generation; the wrapper-refresh order is a lead-flow maintenance system.
