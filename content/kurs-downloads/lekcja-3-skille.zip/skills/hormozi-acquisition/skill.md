---
name: hormozi-acquisition
description: "Doradca ofertowo-cenowy oparty na frameworkach Alexa Hormozi (100M Offers / 100M Money Models / 100M Leads). Uzyj gdy budujesz albo wyceniasz oferte, projektujesz money model, uklad upsell-downsell-continuity, promocje free/discount/premium, albo chcesz ocenic oferte jak Hormozi. Triggers: ocen moja oferte, popraw oferte, jak wycenic, value equation, grand slam offer, money model, hormozi."
---

# Hormozi Acquisition - doradca ofert i cen

Warstwa decyzyjna oparta na trzech ksiazkach Alexa Hormozi: **100M Offers** (co sprzedawac), **100M Money Models** (jak sekwencjonowac oferty, zeby klient sam finansowal pozyskanie), **100M Leads** (jak promowac oferte do zimnego rynku).

To skill przykladowy z kursu Drugi Mozg - pokazuje wzorzec "ksiazka jako skill" (w Dniu 4 zbudujesz taki sam ze swojej ksiazki, przez skill book-to-skill). To warstwa robocza oparta na ksiazkach Hormozi, nie ich zamiennik - po pelen material kup oryginaly.

## Jak uzyc

- **Oceń ofertę:** "oceń moją ofertę jak Hormozi: [wklej ofertę]" - przepuszczę ją przez Value Equation i wskażę najsłabsze ogniwo.
- **Wyceń:** "ile powinienem brać za [X]?" - przez Value Equation + zasady cenowe z cheatsheet.
- **Zbuduj money model:** "jak ułożyć oferty, żeby klient finansował pozyskanie?" - Client Financed Acquisition + 4 typy ofert.
- **Konkretny temat:** value equation, downsell, continuity, guarantee, naming - wyjaśnię i zastosuję.

Gdy pytasz o coś spoza rdzenia frameworków poniżej, czytam odpowiedni rozdział z `chapters/` przed odpowiedzią. Przy wątpliwości sięgam też do `cheatsheet.md` (progi, liczby, reguły decyzyjne), `patterns.md` (każda technika: kiedy / jak / trade-offy), `glossary.md` (definicje).

---

## Rdzeń frameworków

### Kręgosłup: trzy książki, jeden silnik
**Oferta → Money Model → Leads.** Grand Slam Offer staje się *sekwencją* ofert promowanych do obcych. "Nie zdobywamy klientów, żeby sprzedać; sprzedajemy, żeby zdobyć klientów."

### 1. Value Equation - główna soczewka
**Wartość = (Wymarzony efekt × Postrzegane prawdopodobieństwo sukcesu) ÷ (Opóźnienie w czasie × Wysiłek i poświęcenie).**
Rośnij licznik, spychaj mianownik do zera. Początkujący nadmuchują obietnice (góra) - łatwe i nieunikalne. Wygrywa szybkość i łatwość (dół): Apple, Amazon 1-click, Xanax zamiast medytacji. Użyj do diagnozy każdej słabej oferty i do wyceny.

### 2. Grand Slam Offer - sprzedawaj w kategorii jednego
Oferta, której nie da się porównać: atrakcyjna promocja + niedościgła wartość + premium cena + nie do pobicia gwarancja + money model (warunki płatności), który płaci ci za pozyskanie klienta. Podnosi naraz trzy dźwignie wzrostu (odzew, konwersja, cena).

### 3. Starving Crowd - najpierw rynek
Kolejność dźwigni: **Rynek > Oferta > Perswazja.** Oceń rynek: Ogromny ból, Siła nabywcza, Łatwy do namierzenia, Rosnący. Nigdy nie wchodź na kurczący się rynek. Bogactwo w niszach - specyficzność mnoży cenę przy niemal identycznej treści.

### 4. Pięć wzmacniaczy (5 Enhancers)
**Niedobór** (ogranicz ilość) · **Pilność** (ogranicz czas) · **Bonusy** (stackuj nazwane komponenty, nie rabatuj) · **Gwarancje** (odwróć ryzyko - #1 dźwignia konwersji; cztery typy: Bezwarunkowa / Warunkowa / Anty / Domniemana) · **Nazywanie (MAGIC):** Magnet · Avatar · Goal · Interval · Container. Zmieniaj opakowanie, nigdy maszynę.

### 5. Client Financed Acquisition - poprzeczka money modelu
Wyciśnij z jednego klienta w ~30 dni tyle zysku brutto, żeby sfinansować pozyskanie I obsługę 2+ kolejnych. Zwrot mierz w **dniach, nie latach**. Zły money model (CAC > 30-dniowy zysk) to spirala śmierci; dobry zdejmuje gotówkę jako limit wzrostu.

### 6. Cztery typy ofert - sekwencja
- **Attraction:** free/tanie, zamienia obcych w klientów (Win Your Money Back, Giveaway, Decoy, Kup X dostań Y, Zapłać mniej teraz/więcej później).
- **Upsell:** "cokolwiek oferujesz następne", zwykle prawdziwy zysk (Classic, Menu, Anchor, Rollover).
- **Downsell:** zamień "nie" (Plan płatności, Trial z karą, Feature Downsell). Zmień JAK płacą albo CO dostają; nigdy nie rabatuj identycznej rzeczy.
- **Continuity:** przychód cykliczny, uruchamiaj OSTATNI (Continuity Bonus/Discount, Waived Fee).

### 7. Trzy etapy budowy
**Zdobądź gotówkę → Zdobądź więcej → Zdobądź najwięcej.** Dopracuj jedną ofertę naraz. Każdy etap płaci za następny. Simple Scales, Fancy Fails.

### 8. Opakowania promocyjne
Jedną Grand Slam Offer podaj na trzy sposoby: **Premium** (pełna cena, wymaga sprawdzonego procesu + gotówki), **Free** (max odzew, najtańsze leady; monetyzuj dalej), **Discount** (50%+ na wydzielony kawałek). Prawo sekwencji: **Uruchom przepływ → Monetyzuj → Dodaj tarcie.**

---

## Zakres i granice

Pokrywa trzy książki Hormozi. Jego liczby (churn, %, cadence) to jego cytowane wyniki, nie uniwersalne prawa - traktuj jak mocne priory do przetestowania, nie gwarancje. Przy wdrożeniu w konkretnym biznesie połącz z realnymi marżami i rynkiem.

## Indeks rozdziałów (czytaj na żądanie z `chapters/`)

| # | Temat |
|---|-------|
| ch01 | Jak tu doszliśmy (Grand Slam Offer, dwa problemy) |
| ch02 | Ceny (Starving Crowd, virtuous cycle) |
| ch03 | Wartość - stwórz ofertę (Value Equation, 5-krokowy build) |
| ch04 | Wzmacnianie oferty (niedobór, pilność, bonusy, gwarancje, MAGIC) |
| ch05 | Egzekucja (11-punktowy build, First 100k) |
| ch06 | Czym jest money model (Client Financed Acquisition, 30-dniowy test) |
| ch07 | Attraction Offers (Win Your Money Back, Giveaway, Decoy) |
| ch08 | Upsell Offers (Classic, Menu, Anchor, Rollover) |
| ch09 | Downsell Offers (plan płatności, trial z karą) |
| ch10 | Continuity Offers (bonus/discount, billing, 3% fee) |
| ch11 | Zbuduj money model (trzy etapy, 4-krokowy build) |
| ch12 | Promocje premium (opakowanie, Get Flow->Monetize->Friction) |
| ch13 | Promocje free i discount (Friction Ladder, Two-Step Sale) |

## Pliki wspierające
- `cheatsheet.md` - reguły decyzyjne, progi, liczby, tells (warstwa osądu).
- `patterns.md` - każda technika jako Kiedy / Jak / Trade-offy.
- `glossary.md` - kluczowe terminy z definicjami.
- `chapters/` - 13 rozdziałów z frameworkami i przykładami (czytane na żądanie).
