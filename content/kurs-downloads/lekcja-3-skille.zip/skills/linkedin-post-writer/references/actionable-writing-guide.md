# Actionable Writing Guide for LinkedIn Posts

Every post must leave the reader with something they can DO. This guide enforces that standard.

## 1. The Save Test (Pre-Writing Gate)

Before selecting a persona, before scanning templates — answer this:

> "Would a time-poor professional save this post to come back to? What specifically would they re-read or use?"

If no clear answer — rework the idea. Do not proceed.

What "save-worthy" means on LinkedIn:
- An implementable system or process
- A template, checklist, or prompt they can copy
- A contrarian take with evidence they want to cite
- A decision framework they can apply to their own situation
- Steps specific enough to follow without additional research

This is not optional. It gates ALL post creation.

## 2. The Blueprint Principle

**"An insight without a blueprint is entertainment, not education."**

Every post must pass this test: **Can the reader act on this THIS WEEK?**

Not TODAY (LinkedIn professionals may need to prepare resources, align with a team, research a tool). But THIS WEEK. If the answer is "someday" or "in theory" — the post is too abstract.

### The 4 Acceptable Blueprint Forms

Every post must contain at least one:

**1. Numbered steps**
The most common form. Reader follows the sequence to get a result.
```
1. [First action]
2. [Second action]
3. [Third action]
```

**2. Decision framework with criteria**
When the insight is about choosing between approaches.
```
If [situation A] — do [X].
If [situation B] — do [Y].
If unsure — start with [Z] because [reason].
```

**3. Template / prompt / checklist to copy**
The reader copies it directly into their tool, document, or workflow.
```
Here's the exact [template/prompt/checklist]:

[The resource — ready to use, no placeholders that need explanation]
```

**4. Audit checklist**
Reader evaluates their own situation against clear criteria.
```
Check your [X]:
- Does it [criterion 1]? If not: [specific fix]
- Does it [criterion 2]? If not: [specific fix]
- Does it [criterion 3]? If not: [specific fix]
```

If the post contains none of these — it fails the Blueprint Principle. Rework before delivering.

## 3. Prompt Post Framework

Adapted for LinkedIn. Give the reader something to copy, use, and report back on.

### Structure

```
[Hook: Problem or gap they have right now]

Here's [the template / prompt / checklist / framework]:

[The resource — complete, ready to use]

Try this on [specific scenario].

[Collaborative close: "Curious what results you get" / "Report back"]
```

### Why It Works

Reader opens post → reads → copies the resource → opens their tool → applies it → returns to comment with results. This creates:
- Dwell time (reading + copying + applying)
- Saves (want to come back to the resource)
- Comments (reporting results)
- Tags (sharing with colleagues who need this)

A well-executed Prompt Post auto-scores 5/5 on Actionability and 4-5/5 on Dwell Time.

### LinkedIn Adaptation vs. X

On X, prompt posts are compressed (280 chars). On LinkedIn, you have space for:
- Context explaining WHY this resource matters (2-3 lines before the resource)
- A richer resource (multi-step prompts, structured checklists, full frameworks)
- A first comment that extends with usage tips or variations

Use the space. Don't compress unnecessarily.

## 4. Insider Knowledge Framework

When you have domain expertise that most people in the audience lack.

### Structure

```
[X%] of [professional group] don't know this:

[The insight — specific, non-obvious, backed by experience]

Here's how to use it:

[3-5 actionable steps or decision criteria]
```

The "Here's how to use it" block is **non-negotiable**. It is what separates insider knowledge from observation. Without it, you're pointing at things — not teaching how to use them.

### Application Criteria

Use this framework when:
- You have information asymmetry (you know something most of your audience doesn't)
- The insight has a clear application (not just "interesting to know")
- You can back the claim with experience, data, or evidence

Do NOT use when:
- The "insider knowledge" is common knowledge dressed up
- You cannot provide specific steps to apply it
- The insight is opinion without evidence

## 5. Engagement Strategy: Contrarian vs. Collaborative

Every post should use one of these two engagement approaches. Pick one deliberately.

### Professionally Contrarian

Take a clear position that challenges a widely-held professional belief. Not provocative for shock value — the position must be defensible with evidence or experience.

Pattern: "[Accepted practice] is costing you [specific thing]. Here's what I do instead: [actionable alternative]."

LinkedIn readers respect contrarian takes that come with:
- Credentials or experience that earn the right to challenge
- Specific evidence (numbers, case studies, before/after)
- A named alternative they can adopt

### Collaborative

Invite the reader's experience. Frame the post as a perspective, not the final word.

Pattern: "This is the system I use for [X]. Curious whether anyone's tested [variation] — our results were [specific outcome]."

This earns comments because readers feel invited to contribute, not corrected.

### Rules

- Pick one. Apply it deliberately.
- Never mix (creates confused tone).
- Never beg ("What do you think?" as sole CTA is weak — pair with something earned from the post).
- Engagement bait ("Agree? Like if you think so!") is always banned.

## 6. Content Type Performance Ranking (LinkedIn)

### Highest Engagement

1. **Actionable frameworks with numbered steps** — saves, shares to colleagues
2. **Prompt / template posts** — saves, comments with results
3. **Contrarian takes with specific evidence** and a named alternative
4. **Personal transformation stories with concrete metrics** — "I needed to see this" saves
5. **"What nobody tells you about [topic]"** — curiosity + insider knowledge

### Consistent Performers

1. Decision frameworks ("How I decide whether to [X]")
2. Industry observation + specific implication for the reader
3. Lessons from a specific failure with the applied fix
4. Before/after with honest self-assessment

### Engagement Traps (Avoid)

1. Inspirational observations with no executable takeaway
2. Humble brags disguised as professional advice
3. "Agree?" or "What do you think?" without substance to react to
4. Listicles without the "so what" closing synthesis
5. Milestone announcements without a lesson extracted for the reader

## 7. Force Multiplier Language

These rules serve rhythm and authority on LinkedIn. Short sentences hit harder. Commands are clearer than suggestions.

| Instead of... | Write... |
|---------------|----------|
| "that" (where removable) | cut it |
| "in order to" | "to" |
| "because of the fact that" | "because" |
| "you should" | just the command (imperative) |
| "three" / "seven" / "twelve" | "3" / "7" / "12" |
| "at this point in time" | "now" |
| "in the event that" | "if" |
| "due to the fact that" | "because" |
| "it is important to note that" | cut entirely — just state the thing |
| "there are many ways to" | name the specific ways |

**Test:** Read the sentence without the filler word. Does it still make sense? Cut it.

## 8. Scoring Anchors

Use these to calibrate QA scores. When scoring a draft, compare against these benchmarks.

### Actionability

| Score | What It Looks Like |
|-------|-------------------|
| 5/5 | Post contains a ready-to-use template, checklist, or step-by-step process. Reader can open a tool and implement within the hour. |
| 4/5 | Post contains specific guidance and named next steps. Reader knows exactly what to do but may need to adapt to their situation. |
| 3/5 | Post contains principles but no clear steps. Reader is inspired but unclear on what to change. |
| 2/5 | Post is an observation or story with an implicit lesson. Reader might infer an action but it is not stated. |
| 1/5 | Post is pure insight or entertainment. Beautiful thought, nothing to do. |

### Dwell Time Potential

| Score | What It Looks Like |
|-------|-------------------|
| 5/5 | Reader will stop, copy, open a tool, test, and return to comment. Prompt Post format. |
| 4/5 | Reader will save, read again, share with a colleague, or write a substantive comment. |
| 3/5 | Reader will read once, like, scroll on. |
| 2/5 | Reader reads first 3 lines, decides it is not for them. |
| 1/5 | Reader sees hook and scrolls past. |

### Hook Power (LinkedIn-Specific)

| Score | What It Looks Like |
|-------|-------------------|
| 5/5 | Specific number or counterintuitive claim that stops a professional mid-scroll. "3 miesiace temu zrobilem ten blad. Stracilismy klienta." — specific, stakes clear, must read more. |
| 4/5 | Clear value promise or reframe. Reader knows exactly what they are getting. |
| 3/5 | Interesting but vague. Reader might click "see more" if already curious about the topic. |
| 2/5 | Generic opening that could be any LinkedIn post. "Something I learned recently..." |
| 1/5 | Starts with "I" or a statement only interesting to the author. |

### Value Density

| Score | What It Looks Like |
|-------|-------------------|
| 5/5 | Post contains a named framework, specific numbers, and a concrete method. Reader could teach this to a colleague. |
| 4/5 | Post contains a specific insight and clear implication. Reader has a new understanding. |
| 3/5 | Post has a good point but stated once without evidence or application. |
| 2/5 | Post is mostly context-setting with a thin payoff. |
| 1/5 | Post is a general observation with no specific insight. |
