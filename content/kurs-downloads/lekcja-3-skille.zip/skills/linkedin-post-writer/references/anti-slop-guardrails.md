# Anti-Slop Guardrails for LinkedIn Posts

Check every draft against these rules before output. One violation can kill authenticity.

## Banned Patterns

NEVER use these in any LinkedIn post:

| Pattern | Why It's Banned |
|---------|----------------|
| Em dashes (—) for dramatic pauses | AI fingerprint. Use line breaks or fragments instead. |
| "Let me be honest with you" | Implies everything else was dishonest. Sounds scripted. |
| "Here's the thing" | Generic filler. Every LinkedIn bro uses this. |
| "I'll be frank" | Same problem as "let me be honest." |
| "At the end of the day" | Cliche. Says nothing. |
| "It's not about X, it's about Y" (generic form) | Overused reframe structure. Use Luki's specific version instead. |
| Starting with "I" | Weak opening. Start with action, command, or observation. |
| Emojis | Unless user specifically requests them. They cheapen authority posts. |
| "Game-changer" | AI slop signal #1. |
| "Unlock" | AI slop signal #2. |
| "Skyrocket" | AI slop signal #3. |
| "Level up" | AI slop signal #4. |
| Generic motivational closings | "You've got this!" / "The world needs your story" — delete on sight. |
| LinkedIn bro rhetorical questions | "But what if I told you...?" / "Want to know the secret?" — cringe. |

## Required Alternatives

USE these patterns instead:

| Instead of... | Use... | Why |
|---------------|--------|-----|
| Em dashes for pause | Line breaks between short sentences | Creates visual rhythm, not AI fingerprint |
| Filler openings | Fragments for impact ("Słuchajcie." / "Trzy miesiące.") | Immediate pattern interrupt |
| Generic reframes | Luki's specific reframes ("To nie jest błąd techniczny. To błąd strategiczny.") | Ownership through specificity |
| Abstract advice | Concrete examples with numbers and specifics | Authority comes from detail |
| English motivational closings | Direct Polish expressions ("Lecimy z tym." / "I koniec.") | Authentic voice marker |
| Vague frameworks | Named frameworks in quotes ("inżynieria kontekstu", "personalna monopolia", "Brand Brain") | Creates intellectual property |

## LinkedIn-Specific Anti-Patterns

Beyond general anti-slop, watch for these LinkedIn-specific traps:

- **The "I" parade** — Multiple sentences starting with "I did", "I learned", "I realized". Vary sentence openings.
- **The humble brag** — "I never expected my little side project to reach 200K views." Just state the fact.
- **The engagement bait** — "Agree? Like if you think so!" Let the content earn engagement.
- **The thread teaser** — "I'm going to share 7 lessons. Thread below." This isn't X. Write a complete post.
- **The fake vulnerability** — "I almost didn't share this..." then shares a polished corporate insight. Real vulnerability has mess.
- **Wall of text** — No line breaks, no visual hierarchy. LinkedIn is mobile-first. Break it up.
- **Hashtag stuffing** — 15+ hashtags. Max 5-7, only if requested. Content > tags.

## Self-Check Process

Before delivering any post, scan for:

1. Any word from the banned list
2. More than 2 sentences starting with "I" consecutively
3. Any em dash usage
4. Generic closing line
5. Missing line breaks (wall of text)
6. Any phrase you've seen in 10+ other LinkedIn posts this week
