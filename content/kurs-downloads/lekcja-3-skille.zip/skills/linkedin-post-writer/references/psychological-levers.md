# Psychological Levers for LinkedIn Posts

12 core principles that drive behavior (save, comment, DM, follow). Choose 1-2 per post deliberately. State your choice in POST STRATEGY before drafting.

Based on behavioral economics, persuasion research, and platform-specific dynamics. Filtered for Luki's voice and ICP (AI/tech startup founders, marketing directors).

## How to Use

1. After Step 1 (Context Extraction), scan this list
2. Pick 1-2 levers that naturally fit the content
3. State them in POST STRATEGY: `**Psychological Levers:** Scarcity + Loss Aversion`
4. Apply during drafting (Step 4) - weave in, don't force
5. QA check: can you identify where the lever operates in the final post?

**Rule:** Never stack more than 2 levers. Overloading kills authenticity.

---

## The 12 Levers

### 1. SCARCITY
**Principle:** Limited availability increases perceived value.
**LinkedIn application:** "Pracuje z max 3-4 markami jednoczesnie. Jedno miejsce od Q3." / "Ten framework wysylam tylko do osob ktore komentuja."
**When to use:** Lead generation posts, CTA posts, capacity announcements.
**Anti-slop:** Never fake scarcity. "Only 3 spots left" when you have infinite capacity = trust killer. Real scarcity: your time, your capacity, a deadline.

### 2. RECIPROCITY
**Principle:** Free value creates obligation to reciprocate.
**LinkedIn application:** Give a complete framework, template, or checklist. Don't gate everything. The free value earns the right to ask later.
**When to use:** Lead magnet posts, tutorial posts, framework reveals.
**Anti-slop:** Value must be genuine. A "free PDF" that's a sales pitch = negative reciprocity. Give something they'd pay for.

### 3. SOCIAL PROOF
**Principle:** People follow what others are doing.
**LinkedIn application:** "127 startupow wdrozylo ten system" / "Feedback po ostatnim uplywie: [screenshot/quote]" / Specific client results with numbers.
**When to use:** Case study posts, results posts, positioning posts.
**Anti-slop:** Specificity = credibility. "Helped a SaaS go from 400K to 2.1M ARR in 14 months" >> "helped many companies grow."

### 4. PATTERN INTERRUPT
**Principle:** Broken patterns spike attention. The brain is a pattern-recognition machine.
**LinkedIn application:** Opening 2 lines that violate expectations. "Zrobilem 200K w zeszlym roku i zamykam firme." / "Najlepsza rzecz ktora zrobilem dla brandu? Przestalem robic content."
**When to use:** Every post needs a hook. Pattern interrupt = the strongest hook type.
**Anti-slop:** The contradiction must resolve meaningfully. Clickbait without payoff = unfollow.

### 5. ANCHORING
**Principle:** First number mentioned becomes the reference point for all subsequent judgments.
**LinkedIn application:** "Agencje biora 20-30K za to. Retainer u mnie: 8-15K, zero long-term contract." / "Ten system oszczedza 20h tygodniowo. Zbudowanie go zajelo 2 godziny."
**When to use:** Positioning posts, pricing mentions, value demonstrations.
**Anti-slop:** Anchor must be real and verifiable. Don't invent competitor pricing.

### 6. LOSS AVERSION
**Principle:** People are 2x more motivated to avoid losses than to achieve equivalent gains (Kahneman).
**LinkedIn application:** "Bez systemu dystrybucji tracisz 50K rocznie na niewidzialnosc" >> "Z systemem zyskasz 50K."
**When to use:** Problem-awareness posts, "real cost of X" posts, urgency posts.
**Framing rule:** Same information, different frame. Always test: is the loss frame stronger here?

### 7. CURIOSITY GAP
**Principle:** Gap between what we know and what we want to know creates tension (Loewenstein).
**LinkedIn application:** Open loops. "Najwiekszy blad w cold outreachu nie jest tym co myslisz." / "3 klucze do dystrybucji. 2 juz znasz." / Incomplete patterns that demand completion.
**When to use:** Hook construction, multi-part content, thread teasers.
**Anti-slop:** Close the loop in the same post. Open loops without resolution = frustration, not engagement.

### 8. COGNITIVE DISSONANCE
**Principle:** Conflicting beliefs create discomfort. The mind resolves by updating one belief.
**LinkedIn application:** "Myslisz ze wiecej contentu = wiecej zasieg. Data z 18 startupow mowi odwrotnie." / Present data that conflicts with common practice.
**When to use:** Contrarian takes, paradigm shift posts, "everyone does X wrong" posts.
**Anti-slop:** You need EVIDENCE. Opinion without data = hot take. Opinion with data = authority.

### 9. TRIBAL IDENTITY
**Principle:** People act to belong. Us vs. them creates loyalty.
**LinkedIn application:** "Startupy ktore buduja systemy dystrybucji vs. te ktore wrzucaja posty i licza na algorytm." / "Founderzy ktorzy traktuja content jak produkt vs. ci ktorzy traktuja go jak obowiazek."
**When to use:** Positioning posts, values-driven content, community building.
**Anti-slop:** Never punch down. The "them" should be a mindset, not specific people. Tribe = aspiration, not exclusion.

### 10. COMMITMENT ESCALATION
**Principle:** Small yeses lead to bigger yeses (Cialdini). Each commitment makes the next easier.
**LinkedIn application:** Design the path: Like -> Comment keyword -> Receive DM -> Reply to question -> Book call. Each step is a micro-commitment.
**When to use:** Lead magnet posts, funnel-aware posts, CTA design.
**How to apply:** Keyword CTA ("Komentuj DISTRIBUTION") is a commitment. DM follow-up question is another. By call time, they've said yes 3-4 times.

### 11. STRATEGIC VULNERABILITY
**Principle:** Resolved struggles build connection (Brown). Vulnerability + competence = trust.
**LinkedIn application:** "Stracilem klienta bo nie mialem systemu. Oto co zbudowalem." / "Spedzilem 3 miesiace robiac to zle. Oto czego sie nauczylem."
**When to use:** Personal story posts, lesson-learned posts, transformation narratives.
**Anti-slop:** Struggle must be REAL and RESOLVED. "I almost didn't share this..." then sharing a polished insight = fake vulnerability. Real vulnerability has mess AND a lesson.

### 12. PEAK-END RULE
**Principle:** People judge experiences by the peak moment and the ending, not the average (Kahneman).
**LinkedIn application:** Every post needs a PEAK (the insight that makes them think "wow") and a STRONG END (clear takeaway or CTA). The middle can be solid but not extraordinary.
**When to use:** Every post. This is a structural principle, not a content choice.
**How to apply:** Identify your peak sentence. Is it the most powerful line? Move it to the moment of maximum tension. End with either a named framework, a direct CTA, or a one-line verdict.

---

## Quick Reference: Lever x Content Type Matrix

| Content Type | Primary Lever | Secondary Lever |
|-------------|--------------|----------------|
| Lead magnet post | Reciprocity | Scarcity or Commitment Escalation |
| Contrarian take | Cognitive Dissonance | Tribal Identity |
| Case study | Social Proof | Anchoring |
| Personal story | Strategic Vulnerability | Peak-End Rule |
| Framework reveal | Curiosity Gap | Reciprocity |
| Trendjack | Pattern Interrupt | Loss Aversion |
| Tutorial / how-to | Reciprocity | Commitment Escalation |
| Positioning post | Anchoring | Tribal Identity |
| Outreach warming | Social Proof | Loss Aversion |

---

## Scoring Integration

In QA (Step 5), add this check:

> **Lever Check:** Can you identify where the chosen psychological lever operates in the post? If you can't point to the specific sentence/section, the lever isn't working. Either strengthen it or swap for one that fits more naturally.

This is not a scored metric. It's a binary check: lever is present and working, or it's not.
