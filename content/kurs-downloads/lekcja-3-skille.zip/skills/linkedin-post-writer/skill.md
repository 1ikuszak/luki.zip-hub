---
name: linkedin-post-writer
description: "Zamienia surową myśl albo brain dump w gotowy do publikacji post na LinkedIn napisany TWOIM głosem, nie generycznym AI-slopem. Przy pierwszym użyciu buduje twój profil głosu w vaulcie. Triggers: napisz post na LinkedIn, post na LinkedIn, LinkedIn post, zrób z tego posta."
---

# LinkedIn Post Writer

Zamienia brain dump w post na LinkedIn, który brzmi jak ty, a nie jak każdy inny post generowany przez AI. Cała siła siedzi w jednym pliku vaulta: twoim profilu głosu. Skill po niego sięga, a jak go jeszcze nie ma - najpierw go z tobą zbuduje.

## Krok 0: Twój głos (bootstrap przy pierwszym użyciu)

Zanim cokolwiek napiszesz, sprawdź, czy istnieje plik `2-areas/taste/moj-glos.md` w vaulcie.

**Jeśli NIE istnieje** - zanim napiszesz pierwszy post, zbuduj go. Zadaj użytkownikowi te pytania, JEDNO NARAZ, czekając na odpowiedź:

1. Do kogo piszesz na LinkedIn (kto ma to czytać) i co chcesz, żeby o tobie myśleli?
2. Jak brzmisz na luzie - wrzuć 2-3 zdania dokładnie tak, jak sam byś je napisał albo powiedział.
3. Czego w pisaniu nie znosisz, co brzmi dla ciebie sztucznie albo korpo? (wymień słowa/frazy do zakazania)
4. Piszesz po polsku, angielsku, czy miksujesz? Jak miksujesz, to które słowa zostają po angielsku?
5. Trzy rzeczy, na których się znasz i o których możesz pisać z autorytetem?

Z odpowiedzi zbuduj `2-areas/taste/moj-glos.md`: sekcje TON (jak brzmisz), ZAKAZANE (słowa/frazy do unikania), JĘZYK (miks), TEMATY (o czym z autorytetem), PRZYKŁADY (zdania z pytania 2 jako wzorzec rytmu). Pokaż szkic, zapytaj o zgodę, zapisz. Powiedz: "To jest twój głos. Im więcej postów napiszemy, tym go dostroimy - popraw ten plik kiedy chcesz, a każdy kolejny post zmieni się razem z nim."

**Jeśli istnieje** - przeczytaj go i pisz według niego. To jest źródło prawdy o tym, jak brzmisz.

Zawsze wczytaj też `.claude/rules/writing-craft.md` (masz go od Dnia 1) - fizyka zdania pod każdym postem.

## Twarde reguły LinkedIn 2026

- ZERO hashtagów - algorytm karze, sygnalizuje promocję.
- ZERO linków w treści posta - mocno tłumi zasięg.
- ZERO linków w pierwszym komentarzu - LinkedIn wyłapał ten trik.
- CTA: kieruj na maila, DM albo "skomentuj 'X', wyślę ci link".

## Workflow

### 1. Wyciągnij złoto z brain dumpu
Z tego, co wrzucił użytkownik, wyłap: główny insight (ta jedna rzecz, którą naprawdę mówi), do kogo to mówi, i co czytelnik ZROBI po przeczytaniu (konkretny krok, framework, zmiana). Brak jasnej odpowiedzi na "co zrobi" = dopracuj insight, zanim ruszysz.

### 2. Test zapisania (bramka przed pisaniem)
"Czy zajęty profesjonalista zapisałby ten post, żeby do niego wrócić? Co konkretnie by przeczytał drugi raz albo zastosował?" Brak jasnej odpowiedzi = przerób insight. To nie podlega negocjacji. (Pełny opis w `references/actionable-writing-guide.md`.)

### 3. Wybierz szkielet
Przeskanuj `references/templates.md` (160 sprawdzonych szkieletów postów) i wybierz 3-5 pasujących do insightu. Weź ten z najlepszym dopasowaniem treści, struktury i głosu. Żaden nie pasuje - zbuduj własną strukturę z patternów głosu.

### 4. Wybierz 1-2 dźwignie psychologiczne
Z `references/psychological-levers.md` wybierz maks 2 (np. Awersja do straty + Dowód społeczny) i nazwij je wprost. Nie stackuj więcej. Wpleć naturalnie.

### 5. Napisz, stosując wszystkie warstwy naraz
- **Głos:** z `moj-glos.md` - to najważniejsza warstwa. Nazwane frameworki w cudzysłowie. Bezpośredni zwrot do czytelnika.
- **Rytm:** różnicuj długość zdań. Czytaj na głos - brzmi robotycznie, przepisz.
- **Struktura:** szkielet z kroku 3, format mobilny (krótkie akapity, przerwy, hierarchia wizualna).
- **Actionability:** post ma zawierać min. jedno: kroki, framework decyzyjny, kopiowalny szablon albo checklistę. Insight bez ścieżki to rozrywka, nie wartość. (`references/actionable-writing-guide.md`.)
- **Anti-slop:** obowiązkowe. Pełna lista zakazanych fraz w `references/anti-slop-guardrails.md`. Jeden "game-changer" zabija autentyczność.

### 6. Oceń i popraw (QA)
Oceń szkic 0-5 na: Siła hooka, Wierność głosu, Rytm, Gęstość wartości, Trigger zaangażowania, Actionability, Dwell time. Cokolwiek poniżej 4 - nazwij słabość, popraw, dopiero wtedy oddaj. Nie oddawaj posta z jakimkolwiek wynikiem poniżej 4.

## Output

Oddaj gotowy pakiet:
1. **POST** - kompletny, gotowy do publikacji, format mobilny, owinięty w blok kodu (przycisk kopiuj w Obsidianie).
2. **PIERWSZY KOMENTARZ** - value-add do wrzucenia od razu (algorytm nagradza wczesne zaangażowanie), też w bloku kodu.
3. **2-3 ALTERNATYWNE HOOKI** - do wyboru (story / kontra / pytanie).
4. **WYNIKI QA** - tabelka 7 metryk.

Po akceptacji zapisz do vaulta: `2-areas/content/linkedin/YYYY-MM-DD-{slug}.md` (frontmatter: type=content, platform=linkedin, status). Zapytaj o datę publikacji, jeśli nie podano.

## Pliki referencyjne
- `references/templates.md` - 160 szkieletów postów.
- `references/psychological-levers.md` - 12 dźwigni z przykładami.
- `references/anti-slop-guardrails.md` - zakazane frazy + alternatywy.
- `references/actionable-writing-guide.md` - Test zapisania, zasada Blueprintu, kotwice oceny.
