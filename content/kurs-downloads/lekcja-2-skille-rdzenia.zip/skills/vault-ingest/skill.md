---
name: vault-ingest
description: Ingest raw sources from _inbox/ into structured knowledge layer with multi-target routing. One source feeds source summaries, concept pages, entity pages, and cross-references. Use when capturing/organizing external knowledge into your vault. Triggers - "ingest", "ingest [filename]", "ingest auto", "process inbox", "compile inbox", "what's in my inbox", "stale inbox".
---

# Vault Ingest

Ingest raw knowledge sources into your Obsidian vault's knowledge layer. One source touches many files - source summaries, concept pages, entity pages, and cross-references to taste/resources/client areas.

This is the first skill of the SKILLS layer (the CAPTURE + ORGANIZE loop). It takes one raw source from `_inbox/` and scatters it multi-target across the vault.

## Self-Config: Vault Path (FIRST RUN ONLY)

This skill reads and writes the vault relative to the vault root. It uses one variable, `VAULT_ROOT`, set once on first run.

`VAULT_ROOT` = `{{VAULT_ROOT}}`

**On first run, if `VAULT_ROOT` is still `{{VAULT_ROOT}}` (not set):**
1. Set `VAULT_ROOT` to the current working directory (the folder where Claude Code was launched). In the unified setup this IS the vault root.
2. Verify by checking that `_GUIDE.md` AND `_MOC-knowledge.md` exist in that folder (or `2-areas/knowledge/_MOC-knowledge.md`). Presence of both = correct vault root.
3. **If the check is ambiguous** (files not found, or you are launched from somewhere other than the vault root): STOP and ASK the user for the vault root path. Never guess.
4. Once confirmed, overwrite the `{{VAULT_ROOT}}` placeholder in this file with the resolved path (one time), then continue.

After this is set once, all paths below are RELATIVE to `VAULT_ROOT`. Zero hardcoded absolute paths. In the unified setup (Claude Code launched from the vault root), the relative paths just work as-is from the working directory.

The helper script defaults to the current working directory too. If you ever need to point it elsewhere, pass `--vault VAULT_ROOT`.

## Web Clipper Setup

Configure the Obsidian Web Clipper extension:
- **Clip destination:** `_inbox/`
- **Filename template:** `YYYY-MM-DD-{title-slug}.md`

**Frontmatter template (clips):**
```yaml
---
source_type: web-clip
source_url: "{{url}}"
source_title: "{{title}}"
source_author: "{{author}}"
clipped: YYYY-MM-DD
---
```

**Manual capture** (non-web content): create a .md file in `_inbox/` with:
```yaml
---
source_type: manual
source_title: "description"
clipped: YYYY-MM-DD
---
```

> Note: there is no `compiled` flag. "Ingested" is not a state stamped on the raw - ingest deletes the raw outright once the full content lives in `2-areas/knowledge/sources/`. Anything still sitting in `_inbox/` is, by definition, not yet ingested.

## Modes

| Command | Action |
|---------|--------|
| "ingest" | Batch ingest all files in `_inbox/` (Phase 0 normalize first) |
| "ingest [filename]" | Ingest single file |
| "ingest auto" | Batch without discussion (less supervised) |
| "what's in my inbox" | Run `python3 scripts/inbox_status.py --action list` |
| "znormalizuj inbox" / "convert inbox" | Run `python3 scripts/normalize_inbox.py` (Phase 0 standalone) |
| "compile inbox" | Alias for "ingest" (backwards compat with vault-compile) |
| "process inbox" | Alias for "ingest" (backwards compat with vault-compile) |
| "stale inbox" / "what's rotting in my inbox" | Run `python3 scripts/inbox_status.py --action stale --days 7` (review only, lists raw never ingested for > N days, deletes nothing) |

## Ingest Pipeline

### Phase 0: Normalize to Markdown (always first)

The vault has ONE native format: **markdown** - the model reads it best, Obsidian renders it best. Anything else that lands in `_inbox/` (PDF, DOCX, EPUB, HTML, TXT, RTF) gets converted BEFORE any analysis. The user may drop whatever they have - the pipeline meets them there.

1. Run `python3 scripts/normalize_inbox.py --list`. Nothing listed = inbox already pure markdown, skip to Phase 1.
2. Convertibles listed? Run `python3 scripts/normalize_inbox.py`. It writes `<name>.md` next to each original (frontmatter stub + extracted text) and deletes NOTHING.
3. Script says a library is missing? It prints the exact `pip3 install ...` command - propose the install to the user, run it, rerun the script.
4. A file still fails (scanned PDF without text layer, exotic format)? Fall back to reading it yourself (Read handles PDFs natively) and write the `.md` raw by hand. If that fails too - ASK the user, never skip silently.
5. Originals stay in `_inbox/` until their `.md` is fully ingested into `sources/`. Then propose to `trash` BOTH the raw `.md` AND the original binary in one approval.
6. **Large source rule (token offloading).** The scripts flag `[duzy plik]` above ~100k chars (~25k tokens, a 100-page PDF is ~50k). NEVER Read such a file whole into the main context. Instead: (a) the source note gets the full verbatim content MECHANICALLY - Bash `cat` the raw into the note body under a prepended frontmatter, zero context cost; (b) the analysis layer (key takeaways, concepts, entities, connections) comes from a SUBAGENT that reads the file in its own fresh context and returns only a short structured summary - or from chunked reads (Read with offset/limit) if a subagent is unavailable. The main context receives the summary, not the document.

### Phase 1: Context Loading

1. Read `_GUIDE.md` (in the vault root)
2. Read `2-areas/knowledge/_MOC-knowledge.md`
3. Read ALL other MOC files (grep for `_MOC` across the vault) to understand existing topology
4. Run: `python3 scripts/inbox_status.py --action list`
5. If inbox empty, report and stop

### Phase 2: Analysis (per raw file)

0. **RELEVANCE GATE (first, always).** Not everything that lands in `_inbox/` deserves to live in the vault. For each raw file decide:
   - **INGEST** - clearly relevant to the user's work/knowledge: proceed.
   - **DELETE (with reason)** - noise, duplicate, or irrelevant: propose deletion with a one-line reason, wait for approval, then `trash` it. Deletion is a first-class outcome, not a failure.
   - **BORDERLINE - ASK** - unclear value: ask the user one question, never guess.
   - **Own content** (user's drafts/posts) - route to content areas, not the knowledge layer.
   Batch limit: process max 10 files per series; if more wait in `_inbox/`, finish the series, report, and ask before continuing. A gate at the entrance is what keeps the vault a brain, not a landfill.
1. Read the raw content fully (EXCEPT files flagged `[duzy plik]` - for those follow Phase 0 rule 6: mechanical copy + subagent/chunked analysis)
2. Discuss key takeaways with user (skip if "ingest auto")
3. Identify:
   - **Concepts** mentioned (check if concept page exists in `2-areas/knowledge/concepts/`)
   - **Entities** mentioned (check if entity page exists in `2-areas/knowledge/entities/`)
   - **Connections** to existing vault notes (grep for topic keywords)
   - **Contradictions** with existing knowledge
4. Plan multi-target routing:
   - ALWAYS: full source note in `2-areas/knowledge/sources/` (the HOME - full verbatim content + links + images, NOT archive)
   - ALWAYS: update/create concept page in `2-areas/knowledge/concepts/` AND add this source to its `## Wszystkie źródła` section
   - IF entities: update/create entity pages in `2-areas/knowledge/entities/`
   - IF touches taste: update relevant `2-areas/taste/` note
   - IF has technical details: update relevant `3-resources/` note
   - IF client-relevant: update relevant `2-areas/{client}/` note
   - IF it is a reusable PROMPT (image/video gen): route to `3-resources/ai-tools/image-prompts/` (prompt library), not just a source summary
   - **IF routing is unclear** - source_type ambiguous, fits multiple areas, contains a prompt vs a thesis, or you are not sure which skill/destination applies: **STOP and ASK the user where it goes before writing. Never guess a destination. One question beats a misfiled note.**

### Phase 3: Compilation (per raw file)

**For EACH target:**

**Creating new page:**
1. Write note with frontmatter per templates below
2. Add `Part of [[_MOC-knowledge]]` backlink in body
3. Add minimum 3 wikilinks to related notes
4. Add "See Also" section with 2-5 related [[links]]
5. Content = actionable knowledge (not thin summary)
6. **SOURCE pages (`2-areas/knowledge/sources/`) ARE THE HOME for ingested knowledge.** Keep FULL original content verbatim + your analysis/connections ON TOP. NOT a thin distillate (over-compression = "did nothing"). **Preserve links AND images as markdown** (`[text](url)`, `![](img-url)`) - they are part of the source, do not strip them. Preserve critical data 1:1 (prices, dates, URLs, model names, prompts, quotes). Put `source_url` in frontmatter as pointer to original.
7. **Sources/ is the home, NOT archive.** If the user ingests something, it matters to them - it belongs in `2-areas/knowledge/sources/` as a first-class note, not buried in `4-archive/` (archive = cold storage). Because the source note now holds the FULL verbatim content, it IS the preserved record - no separate archive copy needed. After writing the source note, remove the raw from `_inbox/` (use `trash`). Do NOT dump fresh ingested knowledge into `4-archive/ingested-sources/`.

**Updating existing page:**
1. Read existing note
2. Append under `## Update YYYY-MM-DD` section (or merge naturally into existing sections)
3. Add source citation inline
4. Update `updated` field in frontmatter
5. Update `source_count` if applicable
6. Add any new wikilinks

**Cross-referencing rules:**
- **MANDATORY auto-link: the concept hub MUST contain a `## Wszystkie źródła` (All Sources) section that wikilinks EVERY source note feeding it, populated automatically during this ingest.** Never leave source-linking for the user to add by hand. When adding a new source to an existing concept, append its `[[wikilink]]` to that section in the same pass.
- Every concept page links to ALL its source pages (via the section above); every source note links back to its concept(s) + `[[_MOC-knowledge]]` in its own See Also.
- Cite sources inline where referenced: `[Source: [[source-page-name]]]` (wikilink, not bare URL).
- Flag contradictions: `> CONTRADICTION: [old] vs [new] from [source]`
- **Synthesis is on-demand, NOT auto.** Do not create a `syntheses/` note during a routine ingest. Build one only when there is a real cross-domain question or the user asks (syntheses = answers to knowledge queries, per `_GUIDE.md`).

**Default biases:**
- `2-areas/knowledge/` targets: CREATE (one concept = one page)
- Non-knowledge targets (taste, resources, client): UPDATE over CREATE

### Phase 4: Index + Log

1. Update `2-areas/knowledge/_MOC-knowledge.md`:
   - Add links under correct section for new pages
   - Update Stats line with current counts
2. Append to `_LOG.md`: `## [YYYY-MM-DD] ingest | {source title}`
3. Remove the processed raw from `_inbox/` with `trash` (content now lives full in `2-areas/knowledge/sources/`). Do NOT archive fresh knowledge to `4-archive/` - that folder is for retired/cold notes only.

### Phase 5: Batch Intelligence (3+ files only)

Before Phase 3, scan all raw files for:
- Related sources that should share concept pages
- Cross-topic connections worth noting
- Patterns across sources

## Frontmatter Templates

**Source summary** (`2-areas/knowledge/sources/`):
```yaml
---
title: "Source Title - Author Name"
type: note
tags: [source, {domain-tag}]
layer: 3
source_type: book | article | video | podcast | paper | manual
source_author: "Author Name"
source_url: ""
source_year: 2026
created: YYYY-MM-DD
updated: YYYY-MM-DD
status: active
---
```

**Concept page** (`2-areas/knowledge/concepts/`):
```yaml
---
title: "Concept Name"
type: note
tags: [concept, {domain-tag}]
layer: 3
source_count: 1
created: YYYY-MM-DD
updated: YYYY-MM-DD
status: draft | active
---
```

**Entity page** (`2-areas/knowledge/entities/`):
```yaml
---
title: "Entity Name"
type: note
tags: [entity, {entity-type-tag}]
layer: 3
entity_type: person | tool | company | style | movement
source_count: 1
created: YYYY-MM-DD
updated: YYYY-MM-DD
status: draft | active
---
```

**Synthesis page** (`2-areas/knowledge/syntheses/`):
```yaml
---
title: "Synthesis Title"
type: note
tags: [synthesis, {domain-tags}]
layer: 3
source_count: 1
query_origin: "Original question that prompted this"
created: YYYY-MM-DD
updated: YYYY-MM-DD
status: draft | active
---
```

## Page Creation Thresholds

- **Concept page:** Create when a subject appears in 2+ sources OR is a core topic for your work. For single-mention subjects, add to an existing concept page as a subsection.
- **Entity page:** Create for notable people, tools, companies, movements. Minimum: frontmatter + 1 paragraph + links.
- **Stub rule:** NEVER leave a [[wikilink]] pointing to nothing. Create at least a stub (frontmatter + one-line definition + source link).

## Compilation Rules

1. Follow `_GUIDE.md` exactly - frontmatter, linking rules, content rules
2. NEVER use em dashes - use hyphens or restructure
3. Keep source language (Polglish stays Polglish)
4. Preserve critical data: prices, dates, URLs, hex colors, API endpoints, model names
5. Temporal markers: "Learned YYYY-MM-DD from [source]"
6. `source_url` in frontmatter for every source summary
7. Update parent MOC when creating new child notes
8. Layer assignment: knowledge layer notes = 3, MOC = 2
9. Content = actionable knowledge, NOT summary. Prices, model names, specific techniques.
10. Every factual claim cites its source: `[Source: [[page-name]]]`
11. A single source should touch 5-15 files across the vault

## Query Workflow

Not a separate trigger - just a convention when the user asks knowledge questions.

1. Read `2-areas/knowledge/_MOC-knowledge.md` to find relevant pages
2. Read relevant `2-areas/knowledge/` pages + `2-areas/taste/` + `3-resources/` as needed
3. Synthesize answer with `[Source: [[page]]]` citations
4. If the answer is valuable, offer to file it as `2-areas/knowledge/syntheses/{slug}.md`
5. Update `2-areas/knowledge/_MOC-knowledge.md` and `_LOG.md`

Trigger phrases:
- "What does my knowledge base say about X?"
- "How does X connect to Y?"
- "What are the gaps in my knowledge about X?"
- "Write a briefing on X using only wiki content"

## What This Skill Does NOT Do

- Scrape websites (the Web Clipper does that)
- Auto-run on schedule (manual trigger)
- Dump fresh knowledge into `4-archive/` (sources/ is the home; raw is trashed after ingest)
- Create content pieces (that is what content skills do)

## Helper Script

The helper is pure filesystem (list / stats / stale), zero LLM, ZERO deletion. It operates ONLY on `_inbox/` and never removes anything - in line with the doctrine "sources/ is the home, and INGEST trashes each raw the moment it saves the full content to sources/." Because ingest removes raw immediately, there is no `compiled:true` file lingering in `_inbox/` for a cleanup pass to delete - a delete action would be a no-op. So instead of deleting, the `stale` action just SHOWS raw you clipped but never ingested for > N days, so you can ingest them by hand. It defaults to the current working directory as the vault root; pass `--vault` only if you launched Claude Code from outside the vault.

```bash
python3 scripts/inbox_status.py --action list           # List raw waiting to ingest (md + [do konwersji])
python3 scripts/inbox_status.py --action stats          # Stats (count / by source type / oldest)
python3 scripts/inbox_status.py --action stale --days 7 # REVIEW ONLY: raw never ingested for > N days (deletes nothing)
python3 scripts/normalize_inbox.py --list               # What needs conversion to md
python3 scripts/normalize_inbox.py                      # Convert pdf/docx/epub/html/txt/rtf -> md
```
