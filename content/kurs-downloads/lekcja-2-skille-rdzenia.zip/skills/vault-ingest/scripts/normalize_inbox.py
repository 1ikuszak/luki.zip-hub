#!/usr/bin/env python3
"""Normalize non-markdown files in _inbox/ into .md so ingest can process them.

The vault speaks ONE native format: markdown (best for both the model and
Obsidian). This helper converts whatever lands in _inbox/ (.pdf, .docx, .epub,
.html, .txt, .rtf) into a UTF-8 .md file with a minimal frontmatter stub,
written NEXT TO the original. It deletes NOTHING - trashing the original stays
a model decision, made after user approval (same doctrine as ingest itself).

Extraction fallbacks (mirrors book-to-skill):
  .pdf   -> pdftotext CLI, else pypdf, else PyMuPDF (fitz)
  .docx  -> python-docx
  .epub  -> ebooklib + bs4
  .html  -> bs4, else stdlib HTMLParser
  .txt   -> plain read
  .rtf   -> textutil (macOS), else striprtf if installed

Missing library => a human message with the exact pip command, the file is
skipped (exit 0). Nothing crashes, nothing is silently lost.

Usage:
  python3 scripts/normalize_inbox.py                 # convert all non-md in _inbox/
  python3 scripts/normalize_inbox.py --file X.pdf    # convert a single file
  python3 scripts/normalize_inbox.py --list          # only show what needs conversion
  python3 scripts/normalize_inbox.py --vault PATH    # vault root (default: cwd)
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

CONVERTIBLE = {".pdf", ".docx", ".epub", ".html", ".htm", ".txt", ".rtf"}
SOURCE_TYPE = {
    ".pdf": "pdf", ".docx": "document", ".epub": "book",
    ".html": "web-page", ".htm": "web-page", ".txt": "text", ".rtf": "document",
}

# Above this many chars (~25k tokens) the .md is flagged [duzy plik]:
# the model must NOT read it whole into the main context (see skill.md Phase 0).
LARGE_MD_CHARS = 100_000

# PDFs longer than this get [s. N] page anchors so citations can point to a page.
PAGE_MARKERS_MIN_PAGES = 4


def _join_pages(pages: list[str]) -> str:
    """Join per-page texts; add [s. N] anchors for longer documents."""
    pages = [p.strip() for p in pages]
    if len([p for p in pages if p]) < PAGE_MARKERS_MIN_PAGES:
        return "\n\n".join(p for p in pages if p)
    return "\n\n".join(f"[s. {i}]\n\n{p}" for i, p in enumerate(pages, 1) if p)


def _pip_hint(lib: str) -> str:
    return f"brak biblioteki - zainstaluj: pip3 install {lib} - i odpal jeszcze raz"


# ── extractors (return text or raise RuntimeError with a human message) ──

def extract_pdf(path: Path) -> str:
    if shutil.which("pdftotext"):
        r = subprocess.run(["pdftotext", "-layout", str(path), "-"],
                           capture_output=True, text=True, timeout=120)
        if r.returncode == 0 and r.stdout.strip():
            # pdftotext separates pages with form-feed
            return _join_pages(r.stdout.split("\f"))
    try:
        import pypdf
        with open(path, "rb") as f:
            pages = [(p.extract_text() or "") for p in pypdf.PdfReader(f).pages]
        text = _join_pages(pages)
        if text.strip():
            return text
    except ImportError:
        pass
    try:
        import fitz  # PyMuPDF
        with fitz.open(path) as doc:
            pages = [page.get_text() for page in doc]
        text = _join_pages(pages)
        if text.strip():
            return text
    except ImportError:
        pass
    raise RuntimeError(_pip_hint("pypdf") + " (PDF moze tez byc skanem bez warstwy tekstu)")


def extract_docx(path: Path) -> str:
    try:
        import docx  # python-docx
    except ImportError:
        raise RuntimeError(_pip_hint("python-docx"))
    d = docx.Document(str(path))
    parts = []
    for p in d.paragraphs:
        t = p.text.strip()
        if not t:
            continue
        style = (p.style.name or "").lower() if p.style else ""
        if style.startswith("heading"):
            level = "".join(ch for ch in style if ch.isdigit()) or "2"
            parts.append("#" * min(int(level) + 1, 6) + " " + t)
        else:
            parts.append(t)
    for table in d.tables:
        for row in table.rows:
            parts.append(" | ".join(c.text.strip() for c in row.cells))
    return "\n\n".join(parts)


def extract_epub(path: Path) -> str:
    try:
        import ebooklib
        from ebooklib import epub
        from bs4 import BeautifulSoup
    except ImportError:
        raise RuntimeError(_pip_hint("ebooklib beautifulsoup4"))
    book = epub.read_epub(str(path))
    parts = []
    for item in book.get_items_of_type(ebooklib.ITEM_DOCUMENT):
        soup = BeautifulSoup(item.get_content(), "html.parser")
        text = soup.get_text("\n").strip()
        if text:
            parts.append(text)
    return "\n\n".join(parts)


def extract_html(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="replace")
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(raw, "html.parser")
        for tag in soup(["script", "style"]):
            tag.decompose()
        return soup.get_text("\n")
    except ImportError:
        from html.parser import HTMLParser

        class _Text(HTMLParser):
            def __init__(self):
                super().__init__()
                self.chunks: list[str] = []
                self._skip = 0

            def handle_starttag(self, tag, attrs):
                if tag in ("script", "style"):
                    self._skip += 1

            def handle_endtag(self, tag):
                if tag in ("script", "style") and self._skip:
                    self._skip -= 1

            def handle_data(self, data):
                if not self._skip and data.strip():
                    self.chunks.append(data.strip())

        p = _Text()
        p.feed(raw)
        return "\n".join(p.chunks)


def extract_txt(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def extract_rtf(path: Path) -> str:
    if shutil.which("textutil"):  # macOS
        r = subprocess.run(["textutil", "-convert", "txt", "-stdout", str(path)],
                           capture_output=True, text=True, timeout=120)
        if r.returncode == 0 and r.stdout.strip():
            return r.stdout
    try:
        from striprtf.striprtf import rtf_to_text
        return rtf_to_text(path.read_text(encoding="utf-8", errors="replace"))
    except ImportError:
        raise RuntimeError(_pip_hint("striprtf"))


EXTRACTORS = {
    ".pdf": extract_pdf, ".docx": extract_docx, ".epub": extract_epub,
    ".html": extract_html, ".htm": extract_html, ".txt": extract_txt,
    ".rtf": extract_rtf,
}


# ── conversion ──

def clean(text: str) -> str:
    lines = [ln.rstrip() for ln in text.splitlines()]
    out, blank = [], 0
    for ln in lines:
        blank = blank + 1 if not ln else 0
        if blank <= 2:
            out.append(ln)
    return "\n".join(out).strip()


def convert(path: Path) -> Path | None:
    target = path.with_suffix(".md")
    if target.exists():
        print(f"  [skip] {path.name}: {target.name} juz istnieje")
        return None
    try:
        text = clean(EXTRACTORS[path.suffix.lower()](path))
    except RuntimeError as e:
        print(f"  [skip] {path.name}: {e}")
        return None
    except Exception as e:
        print(f"  [skip] {path.name}: konwersja padla ({type(e).__name__}: {e})")
        return None
    if not text:
        print(f"  [skip] {path.name}: zero tekstu po konwersji (skan/obraz?)")
        return None
    fm = (
        "---\n"
        f"source_type: {SOURCE_TYPE[path.suffix.lower()]}\n"
        f'source_title: "{path.stem}"\n'
        f"source_file: \"{path.name}\"\n"
        f"clipped: {date.today().isoformat()}\n"
        "---\n\n"
    )
    target.write_text(fm + text + "\n", encoding="utf-8")
    print(f"  [ok]   {path.name} -> {target.name} ({len(text)} znakow)")
    if len(text) > LARGE_MD_CHARS:
        print(f"  [duzy plik] {target.name}: ~{len(text) // 1000} tys. znakow - NIE czytaj "
              "w calosci do glownego kontekstu (skill.md, Phase 0: kopia mechaniczna + subagent)")
    return target


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--vault", default=".", help="vault root (default: cwd)")
    ap.add_argument("--file", help="convert a single file from _inbox/")
    ap.add_argument("--list", action="store_true", help="only list files needing conversion")
    args = ap.parse_args()

    inbox = Path(args.vault).resolve() / "_inbox"
    if not inbox.is_dir():
        print("No _inbox/ directory found.")
        return 0

    if args.file:
        candidates = [inbox / args.file]
        if not candidates[0].exists():
            print(f"Nie ma pliku: {candidates[0]}")
            return 1
    else:
        candidates = sorted(
            p for p in inbox.iterdir()
            if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in CONVERTIBLE
        )

    if not candidates:
        print("Inbox czysty: wszystko juz w markdown.")
        return 0

    if args.list:
        pending = [p for p in candidates if not p.with_suffix(".md").exists()]
        done = [p for p in candidates if p.with_suffix(".md").exists()]
        for p in pending:
            print(f"  [do konwersji] {p.name}")
        for p in done:
            print(f"  [oryginal, md juz jest] {p.name} -> {p.with_suffix('.md').name}")
        if pending:
            print(f"\nTotal: {len(pending)} plik(ow) do konwersji. "
                  f"Odpal: python3 scripts/normalize_inbox.py")
        else:
            print("\nWszystko juz skonwertowane - oryginaly czekaja na trash po ingestcie.")
        return 0

    converted = [t for p in candidates if (t := convert(p))]
    print(f"\nSkonwertowane: {len(converted)}/{len(candidates)}. "
          "Oryginaly zostaja - po ingestcie model proponuje je wyrzucic (trash, za zgoda).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
