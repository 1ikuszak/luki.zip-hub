#!/usr/bin/env python3
"""Vault inbox filesystem helper: list, stats, stale.

Doktryna ingest (zgodna ze skill.md): sources/ jest DOMEM dla zingestowanej
tresci, raw z _inbox/ jest usuwany (trash) PRZEZ INGEST natychmiast po
zingestowaniu. NIE dumpujemy do 4-archive/. Skoro ingest trashuje raw od razu,
flaga compiled:true nigdy nie zostaje w _inbox/ - osobna akcja kasujaca
('clean po compiled:true') bylaby no-opem. Dlatego ten helper ZERO kasuje:
akcja 'stale' tylko POKAZUJE surowe wrzutki lezace > N dni (zapomniane,
niezingestowane), zebys mogl je recznie przejrzec i zingestowac. Usuwanie raw
robi WYLACZNIE ingest, po zapisaniu pelnej tresci do sources/.

Defaults to the current working directory as the vault root (unified setup:
Claude Code is launched from the vault root). Pass --vault to point elsewhere.
"""

import argparse
import sys
from datetime import datetime, timedelta
from pathlib import Path

try:
    import yaml
except ImportError:
    print("PyYAML is required: pip3 install pyyaml", file=sys.stderr)
    sys.exit(2)

DEFAULT_VAULT = Path.cwd()

# Non-markdown formats normalize_inbox.py can convert - listed so nothing in
# _inbox/ is ever invisible to "what's in my inbox".
CONVERTIBLE = {".pdf", ".docx", ".epub", ".html", ".htm", ".txt", ".rtf"}

# Above this size the raw .md is flagged: read it in chunks / via subagent,
# never whole into the main context (see vault-ingest skill.md, Phase 0).
LARGE_MD_BYTES = 100_000


def list_convertibles(inbox_dir: Path) -> list[Path]:
    """Non-md files waiting for normalize_inbox.py."""
    return sorted(
        p for p in inbox_dir.iterdir()
        if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in CONVERTIBLE
    )


def parse_frontmatter(file_path: Path) -> dict:
    """Parse YAML frontmatter from a markdown file."""
    text = file_path.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return {}
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}
    try:
        return yaml.safe_load(parts[1]) or {}
    except yaml.YAMLError:
        return {}


def list_inbox(vault: Path) -> list[dict]:
    """List all raw files waiting in _inbox/ with their frontmatter."""
    inbox_dir = vault / "_inbox"
    if not inbox_dir.exists():
        print("No _inbox/ directory found.")
        return []

    files = sorted(inbox_dir.glob("*.md"))
    convertibles = list_convertibles(inbox_dir)
    if not files and not convertibles:
        print("Inbox is empty. Nothing waiting to ingest. Nice and clean.")
        return []

    results = []
    for f in files:
        fm = parse_frontmatter(f)
        entry = {
            "filename": f.name,
            "source_type": fm.get("source_type", "unknown"),
            "source_title": fm.get("source_title", f.stem),
            "clipped": str(fm.get("clipped", "unknown")),
        }
        results.append(entry)
        print(f"  [pending] {entry['filename']}")
        print(f"            {entry['source_type']} | {entry['source_title']}")
        size = f.stat().st_size
        if size > LARGE_MD_BYTES:
            print(f"            (duzy plik ~{size // 1000} KB - czytaj czesciami/subagentem, "
                  "nie w calosci; skill.md Phase 0)")

    pending_conv = [p for p in convertibles if not p.with_suffix(".md").exists()]
    done_conv = [p for p in convertibles if p.with_suffix(".md").exists()]
    for p in pending_conv:
        print(f"  [do konwersji] {p.name}")
    for p in done_conv:
        print(f"  [oryginal, md juz jest] {p.name} -> {p.with_suffix('.md').name}")

    print(f"\nTotal: {len(results)} raw file(s) waiting to ingest.")
    if pending_conv:
        print(f"Do konwersji na md: {len(pending_conv)} - odpal: "
              "python3 .claude/skills/vault-ingest/scripts/normalize_inbox.py")
    return results


def show_stats(vault: Path) -> None:
    """Show inbox statistics (count, by source type, oldest waiting clip)."""
    inbox_dir = vault / "_inbox"
    raw_files = list(inbox_dir.glob("*.md")) if inbox_dir.exists() else []

    if not raw_files:
        print("Inbox is empty. Zero raw waiting. All caught up.")
        return

    by_type: dict[str, int] = {}
    oldest = None
    for f in raw_files:
        fm = parse_frontmatter(f)
        st = fm.get("source_type", "unknown")
        by_type[st] = by_type.get(st, 0) + 1
        clipped = fm.get("clipped")
        if clipped and (oldest is None or str(clipped) < str(oldest)):
            oldest = clipped

    print(f"Inbox total (pending ingest): {len(raw_files)} file(s)")
    if by_type:
        print("\nBy source type:")
        for st, count in sorted(by_type.items()):
            print(f"  {st}: {count}")
    if oldest:
        print(f"\nOldest clip waiting: {oldest}")
    print("\nRun an ingest to clear these. (Ingest trashes each raw after saving it to sources/.)")


def show_stale(vault: Path, days: int) -> list[Path]:
    """REVIEW ONLY: list raw clips sitting in _inbox/ longer than N days.

    Zero deletion. These are forgotten captures you clipped but never
    ingested. Ingest is what removes raw (after writing full content to
    sources/), so anything still in _inbox/ is by definition not yet
    ingested. This surfaces the old ones so you can ingest them by hand.
    """
    inbox_dir = vault / "_inbox"
    if not inbox_dir.exists():
        print("No _inbox/ directory found.")
        return []

    cutoff = datetime.now() - timedelta(days=days)
    stale = []
    for f in sorted(inbox_dir.glob("*.md")):
        clipped = datetime.fromtimestamp(f.stat().st_mtime)
        if clipped < cutoff:
            stale.append(f)
            age = (datetime.now() - clipped).days
            print(f"  [stale {age}d] {f.name}")

    if not stale:
        print(f"Nothing stale. No raw older than {days} days waiting in _inbox/. You are on top of it.")
    else:
        print(f"\n{len(stale)} raw clip(s) older than {days} days, never ingested.")
        print("Review each, then run 'ingest [filename]' to file it (or trash it by hand if junk).")
        print("Nothing was deleted - this is review only.")
    return stale


def main():
    parser = argparse.ArgumentParser(description="Vault inbox helper (list / stats / stale, zero deletion)")
    parser.add_argument("--vault", type=Path, default=DEFAULT_VAULT, help="Vault root path (default: current working directory)")
    parser.add_argument("--action", required=True, choices=["list", "stats", "stale"])
    parser.add_argument("--days", type=int, default=7, help="Age threshold in days for the stale action (default: 7)")
    args = parser.parse_args()

    if args.action == "list":
        list_inbox(args.vault)
    elif args.action == "stats":
        show_stats(args.vault)
    elif args.action == "stale":
        show_stale(args.vault, args.days)


if __name__ == "__main__":
    main()
