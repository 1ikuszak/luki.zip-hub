#!/usr/bin/env python3
"""
search_vault.py - HYBRYDOWE wyszukiwanie po vaulcie (semantic + exact, RRF).

  - dense (BGE-M3 cosine): szuka po ZNACZENIU ("za male" -> "ciasne w udach")
  - exact (SQLite FTS5/bm25): szuka po DOKLADNYM tokenie (liczby, nazwy)
Laczone Reciprocal Rank Fusion (RRF, k=60). Zero serwera/chmury/API.

Uzycie:
    python3 search_vault.py --vault . "jak wycenialem premium projekty"
    python3 search_vault.py --vault . "5800" -n 8
    python3 search_vault.py --vault . "pozycjonowanie" --json
"""
import argparse
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

MODEL_NAME = os.environ.get("VAULT_EMBED_MODEL", "BAAI/bge-m3")
RRF_K = 60
ARM_TOPK = 50
STALE_STATUS = {"archived", "outdated", "superseded", "deprecated"}


def demote(sc, path, status):
    f = 1.0
    if path.startswith("4-archive/"):
        f *= 0.88
    if (status or "").lower() in STALE_STATUS:
        f *= 0.90
    return sc * f


def fts_search(conn, query, limit):
    terms = re.findall(r"\w+", query.lower())
    if not terms:
        return []
    match = " OR ".join(f'"{t}"' for t in terms)
    try:
        rows = conn.execute(
            "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ? "
            "ORDER BY bm25(chunks_fts) LIMIT ?", (match, limit)).fetchall()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vault", default=".", help="root vaulta (default: biezacy folder)")
    ap.add_argument("query", help="zapytanie w jezyku naturalnym")
    ap.add_argument("-n", type=int, default=6)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    db_path = Path(args.vault).resolve() / ".vault-index" / "index.db"
    if not db_path.exists():
        sys.exit("Brak indeksu. Odpal najpierw: python3 index_vault.py --vault .")

    import numpy as np
    conn = sqlite3.connect(db_path)
    rows = conn.execute(
        "SELECT id, path, anchor, status, text, embedding FROM chunks").fetchall()
    if not rows:
        sys.exit("Indeks pusty. Odpal: python3 index_vault.py --vault .")

    id_to_idx = {r[0]: i for i, r in enumerate(rows)}
    mat = np.frombuffer(b"".join(r[5] for r in rows), dtype=np.float32)
    mat = mat.reshape(len(rows), -1)

    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer(MODEL_NAME)
    q = np.asarray(model.encode([args.query], normalize_embeddings=True),
                  dtype=np.float32)[0]

    dense_rank = np.argsort(mat @ q)[::-1][:ARM_TOPK]
    fts_ids = fts_search(conn, args.query, ARM_TOPK)

    rrf = {}
    for rank, idx in enumerate(dense_rank):
        rrf[int(idx)] = rrf.get(int(idx), 0.0) + 1.0 / (RRF_K + rank)
    for rank, cid in enumerate(fts_ids):
        idx = id_to_idx.get(cid)
        if idx is not None:
            rrf[idx] = rrf.get(idx, 0.0) + 1.0 / (RRF_K + rank)

    best = {}
    for idx, score in rrf.items():
        _, path, anchor, status, text, _ = rows[idx]
        adj = demote(score, path, status)
        if path not in best or adj > best[path][0]:
            best[path] = (adj, anchor, status, text)
    ranked = sorted(best.items(), key=lambda kv: kv[1][0], reverse=True)[:args.n]

    results = [{"score": round(sc, 4), "path": path, "anchor": anchor,
               "status": status, "snippet": " ".join(text.split())[:200]}
               for path, (sc, anchor, status, text) in ranked]

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for r in results:
            print(f"\n[{r['score']}] {r['path']}  ({r['status'] or 'brak'})")
            print(f"  {r['anchor']}")
            print(f"  {r['snippet']}")


if __name__ == "__main__":
    main()
