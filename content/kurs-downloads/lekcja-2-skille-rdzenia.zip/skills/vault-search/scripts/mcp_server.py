#!/usr/bin/env python3
"""
mcp_server.py - serwer MCP dla vault-search (WARM serving).

Model BGE-M3 + embeddingi laduja sie RAZ (leniwie, przy pierwszym searchu)
i zostaja CIEPLE na cala sesje. Pierwszy search ~12s, kazdy kolejny <0.1s.
Wzorzec jak qmd / Cerebras (MCP retrieval).

Root vaulta: z env VAULT_ROOT (ustawiane w .mcp.json), fallback = cwd.

Rejestracja (z roota vaulta):
    claude mcp add --scope project vault-search --env VAULT_ROOT=$PWD -- \
      python3 .claude/skills/vault-search/scripts/mcp_server.py
"""
import os
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")
import re
import sqlite3
from pathlib import Path

from mcp.server.fastmcp import FastMCP

VAULT = Path(os.environ.get("VAULT_ROOT", ".")).resolve()
DB_PATH = VAULT / ".vault-index" / "index.db"
MODEL_NAME = os.environ.get("VAULT_EMBED_MODEL", "BAAI/bge-m3")
RRF_K = 60
ARM_TOPK = 50
STALE_STATUS = {"archived", "outdated", "superseded", "deprecated"}

mcp = FastMCP("vault-search")

_MODEL = None
_MAT = None
_ROWS = None
_ID2IDX = None


def _ensure_loaded():
    global _MODEL, _MAT, _ROWS, _ID2IDX
    if _MODEL is not None:
        return
    import numpy as np
    from sentence_transformers import SentenceTransformer
    conn = sqlite3.connect(DB_PATH)
    raw = conn.execute(
        "SELECT id, path, anchor, status, text, embedding FROM chunks").fetchall()
    conn.close()
    _ROWS = [(r[0], r[1], r[2], r[3], r[4]) for r in raw]
    _ID2IDX = {r[0]: i for i, r in enumerate(raw)}
    _MAT = np.frombuffer(b"".join(r[5] for r in raw),
                        dtype=np.float32).reshape(len(raw), -1)
    _MODEL = SentenceTransformer(MODEL_NAME)


def _demote(sc, path, status):
    f = 1.0
    if path.startswith("4-archive/"):
        f *= 0.88
    if (status or "").lower() in STALE_STATUS:
        f *= 0.90
    return sc * f


def _fts(query, limit):
    terms = re.findall(r"\w+", query.lower())
    if not terms:
        return []
    match = " OR ".join(f'"{t}"' for t in terms)
    conn = sqlite3.connect(DB_PATH)
    try:
        rows = conn.execute(
            "SELECT rowid FROM chunks_fts WHERE chunks_fts MATCH ? "
            "ORDER BY bm25(chunks_fts) LIMIT ?", (match, limit)).fetchall()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


@mcp.tool()
def vault_search(query: str, n: int = 6) -> list:
    """Hybrydowe (semantic + exact) wyszukiwanie po Twoim vaulcie po ZNACZENIU
    i dokladnych tokenach. Uzyj do pytan o TEMAT/KONCEPT ("co wiem o X",
    "gdzie pisalem o Y"). Zwraca notatki: path, anchor, status, snippet.

    query: zapytanie w jezyku naturalnym.
    n: ile wynikow (default 6).
    """
    import numpy as np
    _ensure_loaded()
    q = np.asarray(_MODEL.encode([query], normalize_embeddings=True),
                  dtype=np.float32)[0]
    dense_rank = np.argsort(_MAT @ q)[::-1][:ARM_TOPK]
    fts_ids = _fts(query, ARM_TOPK)

    rrf = {}
    for rank, idx in enumerate(dense_rank):
        rrf[int(idx)] = rrf.get(int(idx), 0.0) + 1.0 / (RRF_K + rank)
    for rank, cid in enumerate(fts_ids):
        idx = _ID2IDX.get(cid)
        if idx is not None:
            rrf[idx] = rrf.get(idx, 0.0) + 1.0 / (RRF_K + rank)

    best = {}
    for idx, score in rrf.items():
        _, path, anchor, status, text = _ROWS[idx]
        adj = _demote(score, path, status)
        if path not in best or adj > best[path][0]:
            best[path] = (adj, anchor, status, text)
    ranked = sorted(best.items(), key=lambda kv: kv[1][0], reverse=True)[:n]

    return [{"score": round(sc, 4), "path": path, "anchor": anchor,
            "status": status, "snippet": " ".join(text.split())[:200]}
            for path, (sc, anchor, status, text) in ranked]


if __name__ == "__main__":
    mcp.run()
