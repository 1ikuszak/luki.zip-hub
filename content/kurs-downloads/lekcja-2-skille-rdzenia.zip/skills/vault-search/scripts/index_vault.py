#!/usr/bin/env python3
"""
index_vault.py - buduje HYBRYDOWY indeks wyszukiwania nad Twoim vaultem.

Semantic (znaczenie, BGE-M3) + FTS5 (dokladne tokeny: liczby, nazwy).
Jeden plik sqlite, embedding jako BLOB, incremental po hashu pliku.
Zero serwera, zero chmury, zero API.

Uzycie (working-dir = root vaulta, wariant zunifikowany):
    python3 index_vault.py --vault .            # incremental (tylko zmienione)
    python3 index_vault.py --vault . --rebuild  # od zera
    python3 index_vault.py --vault . --stats    # stan indeksu
    python3 index_vault.py --vault . --build-fts # tylko FTS5 (bez re-embedu)
"""
import argparse
import hashlib
import os
import re
import sqlite3
import sys
import time
from pathlib import Path

os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

MODEL_NAME = "BAAI/bge-m3"   # multilingual (polski OK). Zmien przez env VAULT_EMBED_MODEL.
MODEL_NAME = os.environ.get("VAULT_EMBED_MODEL", MODEL_NAME)

# Foldery pomijane (spojne z vault-linter): dane/smieci, nie wiedza.
SKIP_DIRS = {"_inbox", "templates", ".obsidian", ".claude", ".vault-index",
             ".git", "node_modules", "data-bank", "setup-package"}

MAX_CHARS = 2000
FRONT_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)
HEADING_RE = re.compile(r"^(#{1,4})\s+(.*)$", re.MULTILINE)


def iter_notes(vault: Path):
    for p in vault.rglob("*.md"):
        if any(part in SKIP_DIRS for part in p.relative_to(vault).parts):
            continue
        yield p


def parse_frontmatter(text: str):
    title, tags, status = "", "", ""
    m = FRONT_RE.match(text)
    body = text
    if m:
        fm = m.group(1)
        body = text[m.end():]
        for line in fm.splitlines():
            low = line.strip().lower()
            if low.startswith("title:"):
                title = line.split(":", 1)[1].strip()
            elif low.startswith("tags:"):
                tags = line.split(":", 1)[1].strip().strip("[]")
            elif low.startswith("status:"):
                status = line.split(":", 1)[1].strip()
    return title, tags, status, body


def clean(text: str) -> str:
    text = re.sub(r"\[\[([^\]|]+)\|([^\]]+)\]\]", r"\2", text)
    text = re.sub(r"\[\[([^\]]+)\]\]", r"\1", text)
    return text


def chunk_note(path: Path, vault: Path, text: str):
    title, tags, status, body = parse_frontmatter(text)
    if not title:
        title = path.stem.replace("-", " ")
    body = clean(body)
    sections, last, last_head = [], 0, ""
    for m in HEADING_RE.finditer(body):
        if m.start() > last:
            sections.append((last_head, body[last:m.start()]))
        last_head = m.group(2).strip()
        last = m.end()
    sections.append((last_head, body[last:]))
    chunks = []
    for head, seg in sections:
        seg = seg.strip()
        if len(seg) < 20:
            continue
        anchor = f"{title} > {head}".strip(" >")
        for i in range(0, len(seg), MAX_CHARS):
            piece = seg[i:i + MAX_CHARS].strip()
            if len(piece) < 20:
                continue
            payload = f"{anchor}\n{tags}\n{piece}".strip()
            chunks.append((anchor, status, tags, payload))
    return chunks


def file_hash(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def init_db(conn):
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS files (
            path TEXT PRIMARY KEY, hash TEXT, mtime REAL, indexed_at REAL);
        CREATE TABLE IF NOT EXISTS chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            path TEXT, anchor TEXT, status TEXT, tags TEXT,
            text TEXT, embedding BLOB);
        CREATE INDEX IF NOT EXISTS idx_chunks_path ON chunks(path);
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(text);
    """)


def rebuild_fts(conn):
    conn.execute("DROP TABLE IF EXISTS chunks_fts")
    conn.execute("CREATE VIRTUAL TABLE chunks_fts USING fts5(text)")
    rows = conn.execute("SELECT id, text FROM chunks").fetchall()
    conn.executemany("INSERT INTO chunks_fts(rowid, text) VALUES(?,?)", rows)
    conn.commit()
    return len(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vault", default=".", help="root vaulta (default: biezacy folder)")
    ap.add_argument("--rebuild", action="store_true")
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--build-fts", action="store_true")
    args = ap.parse_args()

    vault = Path(args.vault).resolve()
    index_dir = vault / ".vault-index"
    db_path = index_dir / "index.db"
    index_dir.mkdir(exist_ok=True)
    conn = sqlite3.connect(db_path)
    init_db(conn)

    if args.stats:
        nf = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        nc = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        nfts = conn.execute("SELECT COUNT(*) FROM chunks_fts").fetchone()[0]
        print(f"indeks: {nf} plikow, {nc} chunkow, {nfts} w FTS, db={db_path}")
        return
    if args.build_fts:
        n = rebuild_fts(conn)
        print(f"FTS5 przebudowany z {n} chunkow (exact-arm gotowy)")
        return
    if args.rebuild:
        conn.executescript("DELETE FROM files; DELETE FROM chunks;")
        conn.commit()

    seen = {r[0]: r[1] for r in conn.execute("SELECT path, hash FROM files")}
    todo, current = [], set()
    for p in iter_notes(vault):
        rel = str(p.relative_to(vault))
        current.add(rel)
        try:
            text = p.read_text(encoding="utf-8")
        except Exception:
            continue
        h = file_hash(text)
        if seen.get(rel) != h:
            todo.append((rel, p, text, h))

    gone = set(seen) - current
    for rel in gone:
        conn.execute("DELETE FROM chunks WHERE path=?", (rel,))
        conn.execute("DELETE FROM files WHERE path=?", (rel,))
    if gone:
        print(f"usunieto {len(gone)} nieistniejacych plikow z indeksu")

    if not todo:
        conn.commit()
        print("indeks aktualny, nic do zrobienia")
        return

    print(f"do re-indeksu: {len(todo)} plikow (z {len(current)} w vaulcie)")
    all_chunks, chunk_meta = [], []
    for rel, p, text, h in todo:
        for anchor, status, tags, payload in chunk_note(p, vault, text):
            all_chunks.append(payload)
            chunk_meta.append((rel, anchor, status, tags, payload))

    print(f"laduje model {MODEL_NAME} + embed {len(all_chunks)} chunkow...")
    from sentence_transformers import SentenceTransformer
    import numpy as np
    model = SentenceTransformer(MODEL_NAME)
    t0 = time.time()
    embs = model.encode(all_chunks, normalize_embeddings=True,
                        batch_size=32, show_progress_bar=False)
    embs = np.asarray(embs, dtype=np.float32)
    print(f"embed: {time.time()-t0:.1f}s")

    for rel, p, text, h in todo:
        conn.execute("DELETE FROM chunks WHERE path=?", (rel,))
    for (rel, anchor, status, tags, payload), emb in zip(chunk_meta, embs):
        conn.execute(
            "INSERT INTO chunks(path,anchor,status,tags,text,embedding) "
            "VALUES(?,?,?,?,?,?)",
            (rel, anchor, status, tags, payload[:1200], emb.tobytes()))
    now = time.time()
    for rel, p, text, h in todo:
        conn.execute(
            "INSERT OR REPLACE INTO files(path,hash,mtime,indexed_at) "
            "VALUES(?,?,?,?)", (rel, h, p.stat().st_mtime, now))
    conn.commit()
    rebuild_fts(conn)
    nc = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
    print(f"gotowe: {len(all_chunks)} nowych chunkow, indeks ma teraz {nc} (+FTS)")


if __name__ == "__main__":
    main()
