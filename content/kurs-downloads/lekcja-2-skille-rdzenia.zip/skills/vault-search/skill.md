---
name: vault-search
description: Hybrydowe wyszukiwanie po vaulcie po ZNACZENIU (nie tylko po slowie). Semantic (BGE-M3) + exact (FTS5) laczone RRF. Uzywaj gdy szukasz TEMATU/KONCEPTU ("co wiem o X", "gdzie pisalem o Y", "jak robilem Z") a nie pamietasz dokladnego slowa. To POWER-UP nad vault-query (grep): grep szuka po slowie, to szuka po znaczeniu. Triggers - 'przeszukaj vault semantycznie', 'co wiem o', 'gdzie pisalem o', 'znajdz po znaczeniu', 'semantic search'.
---

# vault-search - hybrydowy semantic search (organ RETRIEVE, wersja zaawansowana)

Grep (skill `vault-query`) szuka po DOKLADNYM slowie. Ten skill szuka po ZNACZENIU: "za male" znajdzie notatke o "ciasne w udach", a "cena kursu" znajdzie "297 zl" nawet bez slowa "cena". Plus exact-arm (FTS5) lapie dokladne tokeny (liczby, nazwy), ktore semantyka rozmywa. Dwa ramiona laczone RRF.

**Kiedy tego uzywac, a kiedy vault-query (grep):**
- Pytanie o ZNACZENIE / gdy nie pamietasz slowa -> vault-search (ten skill).
- Dokladny string / znasz plik -> vault-query albo grep. Szybsze, zero zaleznosci.
- **Nie instaluj tego na start.** To power-up "gdy grep zacznie gubic" (drift-test). Maly vault = grep wystarcza (zmierzone: r@3 ~0.69). Dodaj gdy realnie boli.

## Self-Config: Vault Path

`{{VAULT_ROOT}}`

1. Jesli placeholder `{{VAULT_ROOT}}` powyzej jest jeszcze nieustawiony (ciagle pisze `{{VAULT_ROOT}}`):
   - Wykryj root vaulta: jesli w working-dir jest `_GUIDE.md` / `_MOC-knowledge.md`, root = `.` (wariant zunifikowany).
   - Jak niejednoznaczne - DOPYTAJ o sciezke, nie zgaduj.
   - **Zapisz raz:** nadpisz placeholder `{{VAULT_ROOT}}` ustalona wartoscia (np. `.`). Od teraz uzywaj jej bez pytania.
2. Jesli `{{VAULT_ROOT}}` jest juz ustawiony -> uzyj go wprost (w miejsce `.` ponizej).

## Zaleznosci (raz)

```bash
pip3 install sentence-transformers mcp
```
Pierwsze uruchomienie sciaga model BGE-M3 (~570MB, raz). Numpy wchodzi z torch.

## Uzycie (CLI)

```bash
S=.claude/skills/vault-search/scripts
python3 $S/index_vault.py  --vault .              # zbuduj/odswiez indeks (incremental)
python3 $S/index_vault.py  --vault . --stats      # stan indeksu
python3 $S/search_vault.py --vault . "twoje pytanie po polsku"
python3 $S/search_vault.py --vault . "297" --json # dla agenta
```

**Odswiezanie:** indeks to zdjecie w czasie. Po wiekszym wrzucie wiedzy odpal
`index_vault.py --vault .` (incremental = tylko zmienione pliki, sekundy). Mozesz
dopiac to na koniec swojego cotygodniowego skryptu pobierajacego content.

## Warm serving (MCP) - zeby search byl NATYCHMIASTOWY

Zimly load modelu per wywolanie CLI = ~12s. Fix = serwer MCP trzymajacy model cieply:
pierwszy search w sesji ~12s, kazdy kolejny **~0.04s (250x szybciej)**. To ten sam
wzorzec co qmd (HQ) i Cerebras. Rejestracja (z roota vaulta):

```bash
claude mcp add --scope project vault-search --env VAULT_ROOT=$PWD -- \
  python3 .claude/skills/vault-search/scripts/mcp_server.py
```
Potem przy starcie Claude Code zatwierdz serwer (bramka bezpieczeństwa). Od tego
momentu agent wola narzedzie `vault_search` natywnie, ciepło. Szczegoly + rejestracja
w komponencie `11-mcp-search.md`.

## Jak dziala (skrot)

- **Model:** BGE-M3 (multilingual, polski/Polglish OK), dense, lokalny na MPS/CPU.
- **Store:** `.vault-index/index.db` (sqlite: embedding jako BLOB + FTS5). Regenerowalne, dodaj do `.gitignore`.
- **Hybryda:** dense cosine (znaczenie) + FTS5 bm25 (dokladny token), fuzja RRF k=60.
- **Democja:** archiwum/superseded schodza w rankingu (aktualna prawda wygrywa remisy).
- **Incremental:** hash pliku, re-embed tylko zmienione.
- Wyklucza: `_inbox`, `templates`, `.obsidian`, `.claude`, `4-archive` (democja), `data-bank`.

## Uczciwie (drift-test, duch kursu)

Semantic search dokłada ruchoma czesc (model, indeks do odswiezania). Dodaj go DOPIERO
gdy zmierzysz, ze grep gubi (wpisz pytanie parafraza i zobacz, czy grep trafia). Jak
grep wystarcza - zostaw prosto. To jest ta sama dyscyplina co reszta systemu.
