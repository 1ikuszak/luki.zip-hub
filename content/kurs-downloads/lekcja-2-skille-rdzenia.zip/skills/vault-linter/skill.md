---
name: vault-linter
description: "Deterministyczny health-check vaulta wiedzy. Skanuje vault pod katem zepsutych linkow, sierot, braku frontmatter, em-dashy i przestarzalych notatek. Bez LLM, ponizej 5 sekund. Uruchom przed commitem, po wiekszych edycjach/migracjach albo jako cotygodniowa higiena. Triggery PL/EN: 'lint vault', 'vault health', 'check vault', 'vault issues', 'sprawdz vault', 'zdrowie vaulta', 'health-check vaulta'."
---

# Vault Linter

Deterministyczny health-check vaulta wiedzy (Obsidian). Egzekwuje reguly z `_GUIDE.md` jako KOD: schema frontmatter, integralnosc wikilinkow, kompletnosc MOC, konwencje nazewnictwa, zakaz em-dasha. Zero wywolan modelu. Dziala ponizej 5 sekund na kilkuset plikach.

To jest deterministyczny rdzen petli MAINTAIN. Cross-ref, prune i syntezy (osad) robi model osobno; ten skill robi mechaniczna czesc, ktora skrypt zrobi szybciej i bez bledu.

---

## SELF-CONFIG: sciezka vaulta (przeczytaj przy PIERWSZYM uruchomieniu)

`{{VAULT_ROOT}}`

Ten skill operuje na rootcie twojego vaulta. Linter przyjmuje root jako argument `--vault`, wiec nie ma zadnej zaszytej sciezki w kodzie.

Przy pierwszym uruchomieniu ustal root vaulta wedlug tej reguly:

1. Jesli placeholder `{{VAULT_ROOT}}` powyzej jest jeszcze nieustawiony (ciagle pisze `{{VAULT_ROOT}}`):
   - **Wykryj working-dir.** Jesli w obecnym katalogu roboczym (root, z ktorego odpalono Claude Code) lezy `_GUIDE.md` LUB `2-areas/knowledge/_MOC-knowledge.md` LUB foldery PARA (`1-projects/`, `2-areas/`, `_inbox/`) -> to jest root vaulta. W wariancie zunifikowanym (Claude odpalany z roota vaulta, Obsidian otwiera ten sam folder) root = `.` (working-dir).
   - **Jesli niejednoznaczne** (brak tych markerow albo kilku kandydatow) -> **DOPYTAJ usera o sciezke do roota vaulta.** Nie zgaduj.
   - **Zapisz raz:** nadpisz placeholder `{{VAULT_ROOT}}` ustalona wartoscia (np. `.` dla wariantu zunifikowanego albo konkretna sciezka). Od teraz uzywaj jej bez pytania.
2. Jesli `{{VAULT_ROOT}}` jest juz ustawiony -> uzyj go wprost.

**Wariant zunifikowany (rekomendowany):** jeden folder = root vaulta = working-dir Claude Code = vault Obsidiana. `.claude/` siedzi wewnatrz tego folderu. Wtedy `--vault .` zawsze celuje w dobre miejsce, a raport laduje relatywnie w `_inbox/`. Zero sciezek absolutnych.

W przykladach ponizej `--vault .` zaklada wariant zunifikowany (working-dir = root vaulta). Jesli twoj vault lezy gdzie indziej, podstaw ustalony `{{VAULT_ROOT}}` w miejsce `.`.

---

## SOP

### 1. Pelny skan vaulta

```bash
python3 scripts/lint_vault.py --vault .
```

### 2. Skan ograniczony do obszaru (opcjonalnie)

```bash
python3 scripts/lint_vault.py --vault . --scope 2-areas/business
```

### 3. Zapis raportu do _inbox vaulta

```bash
python3 scripts/lint_vault.py \
  --vault . \
  --format markdown \
  --output _inbox/vault-health-YYYY-MM-DD.md
```

Placeholder `YYYY-MM-DD` w sciezce `--output` jest automatycznie podmieniany na dzisiejsza date przez sam skrypt. Nie podstawiaj jej recznie.

### 4. Przejrzyj i napraw

- **Errors** = trzeba naprawic (zepsute linki, brak frontmatter, em-dashe, zle pola, niekompletne MOC).
- **Warnings** = warto naprawic (sieroty, przestarzale notatki, malo linkow, dlugie pliki).

Exit code: `0` gdy brak errorow, `1` gdy sa errory (i `2` przy bledzie uruchomienia, np. zly katalog albo brak PyYAML). Dzieki temu skill nadaje sie do bramki przed commitem.

---

## Flagi CLI

| Flaga | Opis |
|------|------|
| `--vault` | Sciezka do roota vaulta (wymagana). W wariancie zunifikowanym: `.` |
| `--scope` | Podfolder, do ktorego ograniczamy raportowanie (np. `2-areas/business`) |
| `--format` | `terminal` (domyslny, kolorowy) lub `markdown` |
| `--output` | Zapisz raport do pliku zamiast na stdout (z auto-podmiana `YYYY-MM-DD`) |

---

## Kiedy uruchamiac

- Przed commitem zmian w vaulcie.
- Po wiekszych edycjach albo migracjach.
- Cotygodniowa higiena (krok 1 petli MAINTAIN).
- Po dodaniu nowych notatek klienta albo projektu.

---

## Checki

**13 error checks:** frontmatter obecny, wymagane pola, poprawny type/layer/status, format dat, em-dashe, zepsute wikilinki, brak backlinku ('part of [[...]]'), kompletnosc MOC (dziecko nielinkowane), frontmatter contentu/klienta/projektu, format tagow.

**7 warning checks:** malo wikilinkow (<3), brak sekcji 'See Also', dlugie pliki (>300 linii), notatka-sierota, przestarzala notatka (status active, >60 dni od update), zalegly review, niezgodne nazewnictwo plikow contentu (poza wzorem `YYYY-MM-DD-slug.md`).

Skrypt pomija foldery `templates`, `4-archive`, `.obsidian`, `_inbox` (stale `SKIP_DIRS` w kodzie). Wymagane pola frontmatter: `type, tags, layer, created, updated, status`.

---

## Uwaga: dwa rozne lintery

Ten linter (`lint_vault.py`) to **pelny skan on-demand** calego vaulta (warstwa MAINTAIN). To NIE jest to samo co `vault_lint_hook.py` z warstwy GWARANCJI (hook PostToolUse), ktory lintuje TYLKO wlasnie edytowany plik po kazdym Write/Edit i zwraca `exit 2`. Hook pilnuje na biezaco; ten skrypt robi okresowy przeglad calosci. Dwa rozne pliki, dwie rozne role.
