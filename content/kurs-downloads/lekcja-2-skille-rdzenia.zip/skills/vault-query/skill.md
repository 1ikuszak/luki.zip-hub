---
name: vault-query
description: Petla RETRIEVE drugiego mozgu. Pytanie -> czyta wlasciwe _MOC + grep slow kluczowych -> wciaga relevantne notatki -> odpowiada WYLACZNIE z Twojej wiedzy (nie z modelu), kazde twierdzenie z [Source: [[plik]]]. Brak w bazie = mowi wprost, nie zmysla. Triggery - "Zapytaj moj drugi mozg: {pytanie}", "query vault", "zapytaj mozg", "zapytaj vault", "co wiem o ...".
---

# Vault Query

Pytasz swoj drugi mozg. Skill czyta Twoja wiedze z vaulta (notatki .md), nie z glowy modelu, i odpowiada tylko tym, co naprawde masz zapisane. Kazde twierdzenie nosi zrodlo. Jak czegos nie ma w bazie - mowi to wprost, zamiast zmyslac.

> Nota implementacyjna: to ta sama mechanika co regula QUERY w CLAUDE.md (czytaj MOC -> notatki -> cytuj zrodlo -> brak w bazie = powiedz). Wydzielona jako osobny skill dla czystosci - symetria "3 skille rdzenia" (ingest / query / maintenance). Mozesz wolac ja jako skill albo zostawic jako regule w CLAUDE.md - to ten sam proces.

---

## 0. Self-config: gdzie jest vault (raz, przy pierwszym odpaleniu)

Zanim cokolwiek zrobisz, ustal root vaulta. Domyslnie sciezki w tym skillu sa **relatywne od roota vaulta** (np. `2-areas/`, `_GUIDE.md`) - bo Claude Code odpalasz Z folderu vaulta (`cd <twoj-vault> && claude`), wiec working directory = root vaulta.

VAULT_ROOT: `{{VAULT_ROOT}}`

Regula startowa:
1. Jesli `{{VAULT_ROOT}}` jest jeszcze placeholderem (niezustawiony):
   - Sprawdz, czy w obecnym folderze (working directory) jest `_GUIDE.md` LUB `2-areas/knowledge/_MOC-knowledge.md`. Jesli tak -> to jest root vaulta, ustaw `VAULT_ROOT` = working directory.
   - Jesli ich nie ma w obecnym folderze (niejednoznacznie / Claude odpalony poza vaultem) -> **ZAPYTAJ usera o sciezke do vaulta**. Nie zgaduj.
   - Po ustaleniu: nadpisz placeholder `{{VAULT_ROOT}}` raz w tym pliku (Edit), zeby kolejne odpalenia juz nie pytaly.
2. Jesli `VAULT_ROOT` jest juz ustawiony - uzywaj go. Wszystkie sciezki nizej traktuj jako relatywne od niego.

W praktyce: jak odpaliles Claude z roota vaulta (wariant zunifikowany), sciezki relatywne `2-areas/...`, `_GUIDE.md` graja same i nie musisz nic ustawiac.

---

## 1. Co czyta (routing - sciezki relatywne od roota vaulta)

Query NIE skanuje calego vaulta na slepo. Nawiguje przez mapy (MOC), potem zaweza grepem, potem czyta tylko trafione notatki.

| Krok | Co | Sciezka (relatywna) |
|------|-----|---------------------|
| Index wiedzy | glowny MOC warstwy wiedzy | `2-areas/knowledge/_MOC-knowledge.md` |
| Inne MOC domenowe | mapy obszarow (biznes, klienci, taste, projekty...) | `grep -rl "_MOC" .` -> wybierz pasujace do domeny pytania |
| Notatki zrodlowe | pelne tresci ingestowanych zrodel | `2-areas/knowledge/sources/` |
| Notatki konceptowe | hub-y pojec | `2-areas/knowledge/concepts/` |
| Notatki encji | osoby / narzedzia / firmy | `2-areas/knowledge/entities/` |
| Projekty | aktywne projekty (deadline) | `1-projects/` |
| Obszary | ongoing domeny + SOP | `2-areas/` |
| Zasoby | referencja | `3-resources/` |
| Konwencje | format frontmatter, linkowanie | `_GUIDE.md` |

Zero hardcoded sciezek absolutnych. Wszystko liczone od `VAULT_ROOT`.

---

## 2. SOP - sekwencja MOC -> grep -> notatki -> odpowiedz

### Krok 1: Zidentyfikuj domene pytania
Z pytania wyciagnij temat/domene (biznes? klient? konkretne narzedzie? koncept?) i slowa kluczowe (rzeczowniki, nazwy wlasne, terminy domenowe). To one napedza grep.

### Krok 2: Otworz wlasciwe MOC (mapa, nie szukanie)
- Zawsze przeczytaj `2-areas/knowledge/_MOC-knowledge.md` jako punkt wejscia.
- Jesli domena ma swoje MOC (np. klient, biznes, taste) - znajdz je: `grep -rl "_MOC" .` i otworz pasujace. MOC linkuje do klastra notatek - to Twoja mapa, zamiast szukac po omacku otwierasz wlasciwy obszar.

### Krok 3: Grep slow kluczowych po vaulcie
Po slowach z kroku 1 przeszukaj tresc:
```
grep -ril "slowo_kluczowe" . --include="*.md"
```
Lacz wyniki z linkow w otwartych MOC. Pomijaj `4-archive/` (chyba ze user wprost pyta o historyczne) i `_inbox/` (surowe, jeszcze nie wiedza).

### Krok 4: Wciagnij relevantne notatki
Przeczytaj (Read) tylko notatki, ktore wyszly z MOC + grep i naprawde dotykaja pytania. Idz za wikilinkami `[[ ]]` i sekcjami "See Also", jak prowadza do brakujacego kawalka. Nie wciagaj calego vaulta - tylko trafiony klaster.

### Krok 5: Odpowiedz WYLACZNIE z wciagnietej wiedzy
- Buduj odpowiedz tylko z tresci przeczytanych notatek. NIE dokladaj wiedzy modelu, ogolnikow ani "z mojego doswiadczenia".
- Zachowaj jezyk i konkrety zrodla 1:1 (ceny, daty, nazwy modeli, URL, liczby - tak jak zapisane).

### Krok 6: Cytuj zrodlo przy KAZDYM twierdzeniu (obowiazkowe)
Kazde twierdzenie konczy sie zrodlem w formacie:
```
[Source: [[nazwa-pliku]]]
```
- Jedno twierdzenie z dwoch notatek -> oba zrodla: `[Source: [[plik-a]], [[plik-b]]]`.
- Syntez/wniosek laczacy kilka notatek -> wskaz wszystkie zrodla, z ktorych wynika.
- Bez zrodla nie pisz twierdzenia. Jak nie potrafisz go zacytowac z notatki - znaczy, ze go w bazie nie ma (patrz krok 7).

### Krok 7: Brak w bazie = powiedz wprost (nie zmyslaj)
- Jesli po MOC + grep + notatkach nie ma pokrycia dla pytania (lub czesci pytania) - powiedz wprost: **"Tego nie ma w Twoim drugim mozgu."** Wskaz, czego konkretnie brakuje.
- Mozesz dodac: "Chcesz, zebym to zingestowal?" (kieruje do skilla `vault-ingest`) albo zaproponuj, jakie zrodlo by te luke zamknelo.
- NIGDY nie laataj luki wiedza modelu udajac, ze to z bazy. Pol-odpowiedz z jasno oznaczona luka > pewna odpowiedz zmyslona. To cala wartosc drugiego mozgu: ufasz, bo wiesz, ze nie konfabuluje.

---

## 3. Format odpowiedzi (wzor)

```
{Odpowiedz, twierdzenie po twierdzeniu, kazde ze zrodlem.}

Glowny punkt. [Source: [[plik-a]]]
Drugi punkt, niuans. [Source: [[plik-b]]]
Wniosek z polaczenia obu. [Source: [[plik-a]], [[plik-b]]]

Luka (jesli jest): {Czego brakuje} - tego nie ma w bazie.
```

Trzymaj sie 8 regul writing-craft (krotkie zdania, aktywny glos, zero waty, zero em-dash - tylko " - " albo przecinek). Odpowiedz ma byc gesta od konkretu z notatek, nie rozlazla.

---

## 4. Czego skill NIE robi
- Nie pisze do vaulta (to robota `vault-ingest`). Query tylko czyta.
- Nie skanuje calego vaulta brute-force - nawiguje MOC -> grep -> trafiony klaster.
- Nie odpowiada z modelu, gdy bazy nie ma - flaguje luke.
- Zero Pythona. Czysto LLM/SOP: MOC + grep + filesystem (bez manifestu/auto-indexu - mapy i grep wystarczaja).
