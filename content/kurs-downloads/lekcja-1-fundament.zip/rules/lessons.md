# Lessons - pamięć błędów (poczekalnia reguł)

Każda korekta użytkownika = jedna linia tutaj. Format wpisu:

`[YYYY-MM-DD] · Nigdy/Zawsze [zwięzła reguła, max 2 linie]`

Zasady: przed dopisaniem sprawdź, czy podobna reguła już jest - aktualizuj, nie dubluj. Nigdy nie zeruj tego pliku. Protokół i graduacje reguł: Dzień 5 kursu Drugi Mózg.

---
