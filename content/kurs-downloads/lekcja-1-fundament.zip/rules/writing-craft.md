# Writing Craft - jak piszesz każde zdanie

Startowe reguły od Lukiego (kurs Drugi Mózg). To uniwersalna fizyka zdania, nie czyjś styl - dlatego działa u każdego od pierwszego dnia.

Jedna zasada nad wszystkimi: **reguła zarabia na swoje miejsce albo leci.** Nie zgadzasz się z którąś - usuń ją albo przepisz. To twój system.

Źródło craftu: Scott Adams, "The Day You Became a Better Writer".

## 8 reguł - stosuj przy KAŻDYM pisaniu (post, mail, wiadomość, oferta, notatka)

1. **Proste przekonuje.** Jasne w 5 zdaniach bije błyskotliwe w 100.
2. **Zwięzłość = perswazja.** Pierwszy szkic jest zawsze 30-40% za długi. Tnij każde słowo, które nie ciągnie wozu.
3. **Pierwsze zdanie robi całą robotę.** Najciekawsza rzecz NA POCZĄTKU, nie na końcu akapitu.
4. **Jedna myśl na zdanie.** Zdania złożone rozbijaj. Krótkie ląduje, długie przecieka.
5. **Strona czynna.** Podmiot, czasownik, dopełnienie. "Zepsułem to", nie "zostało to zepsute". Nazwij sprawcę.
6. **Tnij wypełniacze.** "bardzo", "naprawdę", "po prostu", "właściwie", "w celu" - usuń albo skróć.
7. **Pisz, jak mówisz.** Żadnego słowa, którego nie powiedziałbyś na głos mądremu znajomemu.
8. **Zero długiego myślnika (em-dash).** Znak rozpoznawczy AI-bełkotu. Zwykły dywiz "-" albo przecinek, albo przebuduj zdanie. (Ulubiona reguła Lukiego. Lubisz długie myślniki? Wywal ją - patrz zasada nad wszystkimi.)

## Test przed wysłaniem - każdy tekst, który wychodzi w świat

Zapytaj: "Krócej, aktywniej, bardziej po ludzku?" Jeśli tak - popraw. Powtarzaj, aż odpowiedź brzmi "nie".

## Test 3 pytań - hooki, oferty, ważne zdania

1. **Widzisz to?** Zamknij oczy - jest obraz? Brak obrazu = abstrakcja, a abstrakcja nie ląduje.
2. **Da się to obalić?** Zdanie, którego nie da się sprawdzić prawdą albo fałszem, jest puste.
3. **Czy tylko ty możesz to powiedzieć?** Konkurent podpisze się bez zmian = zdanie niczyje.

Trzy razy TAK = zostaw. Choć jedno NIE = przepisz albo tnij.
