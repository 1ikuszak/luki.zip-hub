#!/usr/bin/env python3
"""PostToolUse hook: szybki lint pojedynczego pliku vaulta po Write/Edit.

Sprawdza TYLKO edytowany plik (nie caly vault). Egzekwuje twarde reguly z _GUIDE:
- frontmatter obecny (notatka zaczyna sie od --- bloku YAML)
- zero em/en-dash (BANNED; wyjatek: katalogi verbatim trzymaja oryginal)

Exit 2 + stderr -> Claude widzi naruszenie i naprawia je natychmiast.
Pomija: _inbox/ (raw, verbatim), 4-archive/ (immutable), sources/ (pelna tresc verbatim),
templates/, .obsidian/, .claude/ (silnik: rules/skille to nie notatki wiedzy), .git/.

Root vaulta = $CLAUDE_PROJECT_DIR (working-dir Claude Code w wariancie zunifikowanym:
Claude odpalony W folderze vaulta). Zero hardkodu sciezki - dziala u kazdego.
"""
import json
import os
import sys
from pathlib import Path

# Root vaulta = folder z ktorego odpalony Claude Code (wariant zunifikowany).
# Fallback na cwd, jesli env nieustawiony.
VAULT = Path(os.environ.get("CLAUDE_PROJECT_DIR", ".")).resolve()
SKIP_DIRS = ("_inbox", "4-archive", "templates", ".obsidian", ".claude", ".git")
EMDASH_OK_DIRS = (
    "sources",
    "2-areas/knowledge/sources",
)  # pelna tresc verbatim - oryginal moze miec em-dash


def main() -> int:
    try:
        data = json.load(sys.stdin)
    except Exception:
        return 0
    tool_input = data.get("tool_input") or {}
    tool_response = data.get("tool_response") or {}
    fp = tool_input.get("file_path") or tool_response.get("filePath") or ""
    if not fp:
        return 0
    p = Path(fp)
    try:
        rel = p.resolve().relative_to(VAULT)
    except (ValueError, OSError):
        return 0  # plik spoza vaulta - ignoruj
    if p.suffix != ".md" or not p.exists():
        return 0
    rel_s = str(rel)
    if any(rel_s == d or rel_s.startswith(d + "/") for d in SKIP_DIRS):
        return 0
    # pomijaj kazdy podkatalog sources/ (verbatim), gdziekolwiek lezy
    if any(part == "sources" for part in rel.parts[:-1]):
        return 0
    try:
        text = p.read_text(encoding="utf-8")
    except Exception:
        return 0

    problems = []
    if not text.startswith("---"):
        problems.append("brak frontmatter (notatka musi zaczynac sie od --- bloku YAML)")
    if not any(rel_s.startswith(d) for d in EMDASH_OK_DIRS):
        for i, line in enumerate(text.splitlines(), 1):
            if "\u2014" in line or "\u2013" in line:  # em/en-dash (zapis \u zeby ten plik sam przechodzil lint)
                problems.append(f"linia {i}: em/en-dash (BANNED) -> zamien na ' - ' lub przecinek")
            if len(problems) >= 10:
                break

    if problems:
        print(f"[vault-lint] naruszenia w {rel_s}:", file=sys.stderr)
        for pr in problems[:10]:
            print(f"  - {pr}", file=sys.stderr)
        print("Napraw teraz te naruszenia w tym pliku (reguly z _GUIDE).", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
